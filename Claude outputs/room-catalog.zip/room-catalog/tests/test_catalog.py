"""Testy kontraktu katalogu i bramki licencyjnej."""

from __future__ import annotations

import copy
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from catalog.model import (  # noqa: E402
    CatalogError,
    catalog_from_dict,
    load_catalog,
)

DATA = Path(__file__).resolve().parents[1] / "data"


def minimal_raw() -> dict:
    return {
        "schema_version": 1,
        "currency": "PLN",
        "items": [
            {
                "id": "test.podloga",
                "kind": "material",
                "name": "Podloga testowa",
                "brand": "Test",
                "surface": "floor",
                "unit": "m2",
                "waste_factor": 0.05,
                "price": {
                    "net": 100.0,
                    "vat_rate": 0.23,
                    "status": "listed",
                    "date": "2026-09-06",
                },
                "provenance": {
                    "source_url": "https://example.invalid/podloga",
                    "license": "written_consent",
                },
            },
            {
                "id": "test.drzwi",
                "kind": "object",
                "name": "Drzwi testowe",
                "brand": "Test",
                "slot": "door",
                "anchor": "opening",
                "unit": "szt",
                "dimensions_mm": {"w": 800, "d": 40, "h": 2030},
                "model": "models/drzwi.glb",
                "price": {
                    "net": 500.0,
                    "vat_rate": 0.23,
                    "status": "listed",
                    "date": "2026-09-06",
                },
                "provenance": {
                    "source_url": "https://example.invalid/drzwi",
                    "license": "written_consent",
                },
            },
        ],
        "packages": [
            {
                "id": "test",
                "name": "Pakiet testowy",
                "surfaces": {"floor": "test.podloga"},
                "from_takeoff": {"test.drzwi": "doors"},
            }
        ],
    }


class TestKontrakt(unittest.TestCase):
    def test_minimalny_katalog_przechodzi(self):
        catalog = catalog_from_dict(minimal_raw())
        self.assertEqual(catalog.validate(), [])

    def test_przykladowy_katalog_przechodzi_kontrakt(self):
        """Katalog z placeholderami ma byc POPRAWNY strukturalnie -
        blokuje go dopiero bramka licencyjna, nie walidator."""
        catalog = load_catalog(DATA / "catalog.example.json")
        self.assertEqual(catalog.validate(), [])

    def test_zla_wersja_schematu(self):
        raw = minimal_raw()
        raw["schema_version"] = 99
        self.assertTrue(catalog_from_dict(raw).validate())

    def test_duplikat_id(self):
        raw = minimal_raw()
        raw["items"].append(copy.deepcopy(raw["items"][0]))
        with self.assertRaises(CatalogError):
            catalog_from_dict(raw)

    def test_id_w_zlym_formacie(self):
        raw = minimal_raw()
        raw["items"][0]["id"] = "Test Podloga"
        raw["packages"][0]["surfaces"]["floor"] = "Test Podloga"
        errs = catalog_from_dict(raw).validate()
        self.assertTrue(any("id musi byc" in e for e in errs))

    def test_vat_podany_procentowo_zamiast_ulamkiem(self):
        """23 zamiast 0.23 to najlatwiejsza pomylka w tym pliku."""
        raw = minimal_raw()
        raw["items"][0]["price"]["vat_rate"] = 23
        errs = catalog_from_dict(raw).validate()
        self.assertTrue(any("vat_rate" in e for e in errs))

    def test_material_bez_powierzchni(self):
        raw = minimal_raw()
        raw["items"][0]["surface"] = ""
        self.assertTrue(catalog_from_dict(raw).validate())

    def test_obiekt_bez_wymiaru(self):
        raw = minimal_raw()
        del raw["items"][1]["dimensions_mm"]["h"]
        errs = catalog_from_dict(raw).validate()
        self.assertTrue(any("brak wymiaru h" in e for e in errs))

    def test_material_rozliczany_na_sztuki(self):
        raw = minimal_raw()
        raw["items"][0]["unit"] = "szt"
        self.assertTrue(catalog_from_dict(raw).validate())

    def test_licencja_spoza_slownika(self):
        raw = minimal_raw()
        raw["items"][0]["provenance"]["license"] = "chyba-mozna"
        errs = catalog_from_dict(raw).validate()
        self.assertTrue(any("license=" in e for e in errs))

    def test_brak_source_url(self):
        raw = minimal_raw()
        raw["items"][0]["provenance"]["source_url"] = ""
        errs = catalog_from_dict(raw).validate()
        self.assertTrue(any("source_url" in e for e in errs))

    def test_zla_data_ceny(self):
        raw = minimal_raw()
        raw["items"][0]["price"]["date"] = "06.09.2026"
        errs = catalog_from_dict(raw).validate()
        self.assertTrue(any("date" in e for e in errs))

    def test_pakiet_wskazuje_material_na_zla_powierzchnie(self):
        raw = minimal_raw()
        raw["packages"][0]["surfaces"] = {"wall": "test.podloga"}
        errs = catalog_from_dict(raw).validate()
        self.assertTrue(any("jest na floor" in e for e in errs))

    def test_pakiet_wskazuje_nieznane_id(self):
        raw = minimal_raw()
        raw["packages"][0]["surfaces"]["floor"] = "nie.ma.takiego"
        errs = catalog_from_dict(raw).validate()
        self.assertTrue(any("nieznane id" in e for e in errs))

    def test_from_takeoff_z_nieznanym_kluczem(self):
        raw = minimal_raw()
        raw["packages"][0]["from_takeoff"] = {"test.drzwi": "sciany"}
        errs = catalog_from_dict(raw).validate()
        self.assertTrue(any("from_takeoff" in e for e in errs))

    def test_waluta_pozycji_musi_zgadzac_sie_z_katalogiem(self):
        raw = minimal_raw()
        raw["items"][0]["price"]["currency"] = "EUR"
        errs = catalog_from_dict(raw).validate()
        self.assertTrue(any("waluta" in e for e in errs))

    def test_require_valid_rzuca_z_lista_bledow(self):
        raw = minimal_raw()
        raw["items"][0]["provenance"]["license"] = "chyba-mozna"
        with self.assertRaises(CatalogError):
            catalog_from_dict(raw).require_valid()


class TestBramkaLicencyjna(unittest.TestCase):
    def test_pisemna_zgoda_i_cena_z_cennika_przechodza(self):
        catalog = catalog_from_dict(minimal_raw())
        self.assertTrue(catalog.items["test.podloga"].client_safe)
        self.assertEqual(catalog.items["test.podloga"].blockers(), [])

    def test_strefa_projektanta_nie_przechodzi(self):
        raw = minimal_raw()
        raw["items"][0]["provenance"]["license"] = "designer_zone"
        item = catalog_from_dict(raw).items["test.podloga"]
        self.assertFalse(item.client_safe)
        self.assertTrue(any("licencja" in b for b in item.blockers()))

    def test_cena_placeholder_nie_przechodzi(self):
        raw = minimal_raw()
        raw["items"][0]["price"]["status"] = "placeholder"
        item = catalog_from_dict(raw).items["test.podloga"]
        self.assertFalse(item.client_safe)
        self.assertTrue(any("cena" in b for b in item.blockers()))

    def test_cc0_przechodzi(self):
        raw = minimal_raw()
        raw["items"][0]["provenance"]["license"] = "cc0"
        self.assertTrue(catalog_from_dict(raw).items["test.podloga"].client_safe)

    def test_example_only_nie_przechodzi(self):
        raw = minimal_raw()
        raw["items"][0]["provenance"]["license"] = "example_only"
        self.assertFalse(catalog_from_dict(raw).items["test.podloga"].client_safe)

    def test_obiekt_bez_pliku_modelu_jest_zablokowany(self):
        raw = minimal_raw()
        raw["items"][1]["model"] = ""
        item = catalog_from_dict(raw).items["test.drzwi"]
        self.assertTrue(any("modelu" in b for b in item.blockers()))

    def test_caly_przykladowy_katalog_jest_zablokowany_poza_aranzacja(self):
        catalog = load_catalog(DATA / "catalog.example.json")
        safe = {i.id for i in catalog.items.values() if i.client_safe}
        self.assertEqual(safe, {"staging.roslina.monstera"})


if __name__ == "__main__":
    unittest.main()

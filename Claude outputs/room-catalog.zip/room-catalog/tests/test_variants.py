"""Testy kontraktu wariantow - tego, co przegladarka dostaje do reki."""

from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from catalog.apartment import apartment_from_scene  # noqa: E402
from catalog.casework import load_kits, plan_run  # noqa: E402
from catalog.model import load_catalog  # noqa: E402
from catalog.variants import (  # noqa: E402
    CASEWORK_SLOTS,
    ROOM_SLOTS,
    build_variants,
    client_safe_variants,
)

DATA = Path(__file__).resolve().parents[1] / "data"


def zbuduj(**nadpisz):
    with open(DATA / "mieszkanie.example.json", encoding="utf-8") as handle:
        mieszkanie = apartment_from_scene(json.load(handle))
    catalog = load_catalog(DATA / "catalog.example.json")
    params = dict(
        kits=load_kits(DATA / "catalog.example.json"),
        casework_runs=[
            (plan_run("dolne", "base", 3000), "kuchnia"),
            (plan_run("gorne", "wall", 2400), "kuchnia"),
        ],
        generated="2026-09-06",
    )
    params.update(nadpisz)
    return build_variants(catalog, mieszkanie, **params)


class TestDokument(unittest.TestCase):
    def setUp(self):
        self.doc = zbuduj()

    def test_ma_wszystkie_pakiety(self):
        self.assertEqual(
            [v["id"] for v in self.doc["variants"]], ["comfort", "premium", "standard"]
        )

    def test_niesie_obrysy_wszystkich_pomieszczen(self):
        pokoje = self.doc["apartment"]["rooms"]
        self.assertEqual(len(pokoje), 5)
        for pokoj in pokoje:
            self.assertGreaterEqual(len(pokoj["outline_m"]), 3)
            self.assertGreater(pokoj["wall_height_m"], 0)

    def test_sumy_mieszkania(self):
        m = self.doc["apartment"]
        self.assertAlmostEqual(m["floor_area_m2"], 59.573, places=2)
        self.assertEqual(m["doors"], 4)

    def test_dokument_da_sie_zserializowac(self):
        json.dumps(self.doc, ensure_ascii=False)


class TestMaterialyPerPomieszczenie(unittest.TestCase):
    def setUp(self):
        self.doc = zbuduj()
        self.w = {v["id"]: v for v in self.doc["variants"]}

    def test_kazdy_wariant_opisuje_kazde_pomieszczenie(self):
        for wariant in self.doc["variants"]:
            self.assertEqual(len(wariant["rooms"]), 5, wariant["id"])

    def test_lazienka_ma_plytke_a_salon_farbe(self):
        std = self.w["standard"]["rooms"]
        self.assertEqual(std["salon"]["materials"]["wall"]["item_id"], "farba.sciana.biel")
        self.assertEqual(
            std["lazienka"]["materials"]["wall"]["item_id"], "cersanit.plytka.calm-colours"
        )

    def test_lazienka_nie_ma_listwy(self):
        """Pusta wartosc w pakiecie znaczy brak elementu, a nie material bialy."""
        self.assertNotIn("skirting", self.w["standard"]["rooms"]["lazienka"]["materials"])
        self.assertIn("skirting", self.w["standard"]["rooms"]["salon"]["materials"])

    def test_material_niesie_format_modulu(self):
        plytka = self.w["premium"]["rooms"]["lazienka"]["materials"]["wall"]
        self.assertEqual(plytka["module_mm"], [300, 900])

    def test_warianty_roznia_sie_w_kazdym_pomieszczeniu(self):
        for room_id in ("salon", "lazienka", "kuchnia"):
            std = self.w["standard"]["rooms"][room_id]["materials"]["floor"]["item_id"]
            prem = self.w["premium"]["rooms"][room_id]["materials"]["floor"]["item_id"]
            self.assertNotEqual(std, prem, room_id)

    def test_kazde_pomieszczenie_ma_wlasna_cene(self):
        for pokoj in self.w["standard"]["rooms"].values():
            self.assertIn("net", pokoj["price"])

    def test_sloty_pokojowe_i_zabudowy_sa_rozlaczne(self):
        self.assertEqual(set(ROOM_SLOTS) & set(CASEWORK_SLOTS), set())


class TestZabudowaWMieszkaniu(unittest.TestCase):
    def setUp(self):
        self.doc = zbuduj()

    def test_bryly_zabudowy_znaja_swoje_pomieszczenie(self):
        self.assertTrue(self.doc["casework"])
        self.assertTrue(all(b["room"] == "kuchnia" for b in self.doc["casework"]))

    def test_zabudowa_stoi_w_obrysie_kuchni(self):
        """Kuchnia zaczyna sie na y = 4,35 m, wiec bryly nie moga lezec
        w salonie ponizej tej linii."""
        for b in self.doc["casework"]:
            self.assertGreater(b["y_mm"], 4000)

    def test_fronty_zabudowy_zaleza_od_pakietu(self):
        w = {v["id"]: v for v in self.doc["variants"]}
        self.assertEqual(
            w["standard"]["casework_materials"]["casework_front"]["item_id"],
            "plyta.front.18",
        )
        self.assertEqual(
            w["premium"]["casework_materials"]["casework_front"]["item_id"],
            "plyta.front.fornir",
        )

    def test_bez_zabudowy_sloty_zabudowy_sa_puste(self):
        doc = zbuduj(casework_runs=[])
        for wariant in doc["variants"]:
            self.assertEqual(wariant["casework_materials"], {})
        self.assertEqual(doc["casework"], [])

    def test_nieznany_zestaw_zabudowy(self):
        with self.assertRaises(KeyError):
            zbuduj(kits={})


class TestCenaIBramka(unittest.TestCase):
    def setUp(self):
        self.doc = zbuduj()

    def test_wszystkie_przykladowe_warianty_sa_robocze(self):
        for wariant in self.doc["variants"]:
            self.assertTrue(wariant["draft"], wariant["id"])

    def test_nic_nie_przechodzi_do_klienta(self):
        self.assertEqual(client_safe_variants(self.doc), [])

    def test_cena_calosci_nie_mniejsza_niz_suma_pomieszczen(self):
        """Do ceny mieszkania wchodzi jeszcze zabudowa i pozycje wspolne."""
        for wariant in self.doc["variants"]:
            suma_pokoi = sum(p["price"]["net"] for p in wariant["rooms"].values())
            self.assertGreaterEqual(wariant["price"]["net"] + 1e-6, suma_pokoi)

    def test_brutto_rowne_netto_plus_vat(self):
        for wariant in self.doc["variants"]:
            c = wariant["price"]
            self.assertAlmostEqual(c["gross"], c["net"] + c["vat"], places=2)

    def test_zastrzezenia_sie_nie_powtarzaja(self):
        for wariant in self.doc["variants"]:
            self.assertEqual(
                len(wariant["blockers"]), len(set(wariant["blockers"])), wariant["id"]
            )


class TestObiekty(unittest.TestCase):
    def setUp(self):
        self.w = {v["id"]: v for v in zbuduj()["variants"]}

    def test_drzwi_licza_sie_raz_na_mieszkanie(self):
        drzwi = next(
            o for o in self.w["standard"]["objects"]
            if o["item_id"] == "porta.drzwi.verte-home"
        )
        self.assertEqual(drzwi["count"], 4)

    def test_comfort_ma_sofe_a_standard_nie(self):
        ids = lambda w: {o["item_id"] for o in self.w[w]["objects"]}
        self.assertIn("brw.sofa.trzyosobowa", ids("comfort"))
        self.assertNotIn("brw.sofa.trzyosobowa", ids("standard"))


if __name__ == "__main__":
    unittest.main()

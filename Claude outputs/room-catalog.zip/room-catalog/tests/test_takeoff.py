"""Testy przedmiaru. Liczby sprawdzone rachunkiem recznym, nie odczytane z kodu."""

from __future__ import annotations

import json
import math
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from catalog.takeoff import (  # noqa: E402
    Opening,
    TakeoffError,
    compute_takeoff,
    polygon_area,
    polygon_perimeter,
    takeoff_from_scene,
)

DATA = Path(__file__).resolve().parents[1] / "data"

# Obrys L z data/scene.example.json.
# Prostokat 6x3 = 18 m2 plus prostokat 2x3 = 6 m2, razem 24 m2.
# Obwod: 6 + 3 + 4 + 3 + 2 + 6 = 24 m.
L_OUTLINE = [(0.0, 0.0), (6.0, 0.0), (6.0, 3.0), (2.0, 3.0), (2.0, 6.0), (0.0, 6.0)]


class TestGeometria(unittest.TestCase):
    def test_pole_prostokata(self):
        self.assertAlmostEqual(polygon_area([(0, 0), (4, 0), (4, 3), (0, 3)]), 12.0)

    def test_pole_obrysu_L(self):
        self.assertAlmostEqual(polygon_area(L_OUTLINE), 24.0)

    def test_pole_nie_zalezy_od_kierunku_obrysu(self):
        """Blad znaleziony wczesniej w generatorze: obrys zapisany zgodnie
        z ruchem wskazowek zegara dawal inny wynik niz przeciwnie."""
        self.assertAlmostEqual(
            polygon_area(L_OUTLINE),
            polygon_area(list(reversed(L_OUTLINE))),
        )

    def test_obwod_obrysu_L(self):
        self.assertAlmostEqual(polygon_perimeter(L_OUTLINE), 24.0)

    def test_obwod_trojkata_pitagorejskiego(self):
        self.assertAlmostEqual(polygon_perimeter([(0, 0), (3, 0), (3, 4)]), 12.0)

    def test_za_malo_wierzcholkow(self):
        with self.assertRaises(TakeoffError):
            polygon_area([(0, 0), (1, 1)])


class TestPrzedmiar(unittest.TestCase):
    def setUp(self):
        self.openings = [
            Opening("door", 0.9, 2.05),
            Opening("door", 0.9, 2.05),
            Opening("window", 1.4, 1.5),
            Opening("window", 1.4, 1.5),
        ]
        self.t = compute_takeoff(L_OUTLINE, 2.7, self.openings)

    def test_podloga_i_sufit_rowne(self):
        self.assertAlmostEqual(self.t.floor_area_m2, 24.0)
        self.assertAlmostEqual(self.t.ceiling_area_m2, 24.0)

    def test_sciany_brutto(self):
        # 24 m obwodu * 2,7 m = 64,8 m2
        self.assertAlmostEqual(self.t.wall_area_gross_m2, 64.8)

    def test_sciany_netto(self):
        # otwory: 2 * (0,9 * 2,05) + 2 * (1,4 * 1,5) = 3,69 + 4,20 = 7,89
        # 64,8 - 7,89 = 56,91
        self.assertAlmostEqual(self.t.wall_area_net_m2, 56.91)

    def test_listwy_pomijaja_swiatlo_drzwi(self):
        # 24 m obwodu - 2 * 0,9 m drzwi = 22,2 m
        self.assertAlmostEqual(self.t.skirting_m, 22.2)

    def test_okna_nie_przerywaja_listwy(self):
        bez_okien = compute_takeoff(
            L_OUTLINE, 2.7, [o for o in self.openings if o.kind == "door"]
        )
        self.assertAlmostEqual(bez_okien.skirting_m, self.t.skirting_m)

    def test_zliczanie_otworow(self):
        self.assertEqual(self.t.doors, 2)
        self.assertEqual(self.t.windows, 2)

    def test_ilosc_dla_powierzchni(self):
        self.assertAlmostEqual(self.t.quantity_for_surface("floor"), 24.0)
        self.assertAlmostEqual(self.t.quantity_for_surface("wall"), 56.91)
        self.assertAlmostEqual(self.t.quantity_for_surface("skirting"), 22.2)

    def test_nieznana_powierzchnia(self):
        with self.assertRaises(TakeoffError):
            self.t.quantity_for_surface("dach")


class TestPrzedmiarBledy(unittest.TestCase):
    def test_ujemna_wysokosc(self):
        with self.assertRaises(TakeoffError):
            compute_takeoff(L_OUTLINE, -2.7)

    def test_otwor_wiekszy_niz_sciany(self):
        with self.assertRaises(TakeoffError):
            compute_takeoff(L_OUTLINE, 2.7, [Opening("window", 40.0, 2.0)])

    def test_drzwi_szersze_niz_obwod(self):
        with self.assertRaises(TakeoffError):
            compute_takeoff(
                [(0, 0), (1, 0), (1, 1), (0, 1)],
                2.7,
                [Opening("door", 4.5, 2.0)],
            )

    def test_niedodatni_wymiar_otworu(self):
        with self.assertRaises(TakeoffError):
            compute_takeoff(L_OUTLINE, 2.7, [Opening("door", 0.0, 2.05)])


class TestAdapterSceny(unittest.TestCase):
    def test_wczytanie_przykladowej_sceny(self):
        with open(DATA / "scene.example.json", encoding="utf-8") as handle:
            scene = json.load(handle)
        t = takeoff_from_scene(scene)
        self.assertAlmostEqual(t.floor_area_m2, 24.0)
        self.assertAlmostEqual(t.wall_area_net_m2, 56.91)
        self.assertEqual(t.doors, 2)

    def test_akceptuje_wierzcholki_jako_slowniki(self):
        scene = {
            "room": {
                "outline": [
                    {"x": 0, "y": 0},
                    {"x": 4, "y": 0},
                    {"x": 4, "y": 3},
                    {"x": 0, "y": 3},
                ],
                "wall_height": 2.5,
            }
        }
        self.assertAlmostEqual(takeoff_from_scene(scene).floor_area_m2, 12.0)

    def test_akceptuje_polskie_nazwy_otworow(self):
        scene = {
            "room": {
                "obrys": [[0, 0], [4, 0], [4, 3], [0, 3]],
                "wysokosc_scian": 2.5,
                "otwory": [{"rodzaj": "drzwi", "szerokosc": 0.9, "wysokosc": 2.05}],
            }
        }
        self.assertEqual(takeoff_from_scene(scene).doors, 1)

    def test_brak_obrysu_mowi_czego_szukal(self):
        with self.assertRaises(TakeoffError) as ctx:
            takeoff_from_scene({"room": {"wall_height": 2.5}})
        self.assertIn("outline", str(ctx.exception))

    def test_nieznany_rodzaj_otworu(self):
        scene = {
            "room": {
                "outline": [[0, 0], [4, 0], [4, 3], [0, 3]],
                "wall_height": 2.5,
                "openings": [{"kind": "luk", "width": 1.0, "height": 2.0}],
            }
        }
        with self.assertRaises(TakeoffError):
            takeoff_from_scene(scene)


if __name__ == "__main__":
    unittest.main()

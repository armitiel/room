"""Testy mieszkania: sumowanie pomieszczen i trzy pulapki rachunkowe."""

from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from catalog.apartment import (  # noqa: E402
    Apartment,
    apartment_from_scene,
    quote_all_packages_for_apartment,
    quote_apartment,
    quote_room,
)
from catalog.model import catalog_from_dict, load_catalog  # noqa: E402
from catalog.takeoff import TakeoffError  # noqa: E402

DATA = Path(__file__).resolve().parents[1] / "data"


def scena():
    with open(DATA / "mieszkanie.example.json", encoding="utf-8") as handle:
        return json.load(handle)


def dwa_pokoje(**nadpisz):
    """Dwa pokoje 4x3 obok siebie, ze wspolnymi drzwiami."""
    drzwi = {"id": "d.wspolne", "kind": "door", "width": 0.9, "height": 2.0}
    raw = {
        "rooms": [
            {
                "id": "a", "name": "A", "type": "salon",
                "outline": [[0, 0], [4, 0], [4, 3], [0, 3]],
                "wall_height": 2.5,
                "openings": [dict(drzwi)],
            },
            {
                "id": "b", "name": "B", "type": "lazienka",
                "outline": [[4.2, 0], [8.2, 0], [8.2, 3], [4.2, 3]],
                "wall_height": 2.5,
                "openings": [dict(drzwi)],
            },
        ]
    }
    raw.update(nadpisz)
    return apartment_from_scene(raw)


class TestSumowanie(unittest.TestCase):
    def setUp(self):
        self.m = dwa_pokoje()

    def test_podloga_to_suma_pokoi(self):
        # 4 x 3 dwa razy = 24 m2
        self.assertAlmostEqual(self.m.floor_area_m2, 24.0)

    def test_sciana_dzialowa_liczy_sie_z_obu_stron(self):
        """Kazdy pokoj wnosi swoj pelny obwod - malujesz obie strony scianki."""
        # obwod 14 m * 2,5 m = 35 m2 brutto na pokoj, minus drzwi 1,8 m2
        self.assertAlmostEqual(self.m.wall_area_net_m2, 2 * (35.0 - 1.8))

    def test_listwy_to_suma_pokoi(self):
        # (14 - 0,9) * 2
        self.assertAlmostEqual(self.m.skirting_m, 2 * 13.1)


class TestWspolneOtwory(unittest.TestCase):
    def test_drzwi_miedzy_pokojami_licza_sie_raz(self):
        """Te same drzwi sa na liscie obu pokoi. Bez wspolnego id weszlyby
        do wyceny dwa razy."""
        self.assertEqual(dwa_pokoje().doors, 1)

    def test_otwory_bez_id_licza_sie_osobno(self):
        m = dwa_pokoje()
        surowe = {
            "rooms": [
                {
                    "id": "a", "outline": [[0, 0], [4, 0], [4, 3], [0, 3]],
                    "wall_height": 2.5,
                    "openings": [{"kind": "door", "width": 0.9, "height": 2.0}],
                },
                {
                    "id": "b", "outline": [[4.2, 0], [8.2, 0], [8.2, 3], [4.2, 3]],
                    "wall_height": 2.5,
                    "openings": [{"kind": "door", "width": 0.9, "height": 2.0}],
                },
            ]
        }
        self.assertEqual(apartment_from_scene(surowe).doors, 2)
        self.assertEqual(m.doors, 1)

    def test_przejscie_bez_drzwi_nie_jest_drzwiami(self):
        surowe = {
            "rooms": [{
                "id": "a", "outline": [[0, 0], [4, 0], [4, 3], [0, 3]],
                "wall_height": 2.5,
                "openings": [
                    {"kind": "passage", "width": 1.6, "height": 2.2},
                    {"kind": "door", "width": 0.9, "height": 2.0},
                ],
            }]
        }
        m = apartment_from_scene(surowe)
        self.assertEqual(m.doors, 1)
        # ale przerywa listwe tak samo jak drzwi: 14 - 1,6 - 0,9
        self.assertAlmostEqual(m.rooms[0].takeoff.skirting_m, 11.5)

    def test_okno_nie_przerywa_listwy(self):
        surowe = {
            "rooms": [{
                "id": "a", "outline": [[0, 0], [4, 0], [4, 3], [0, 3]],
                "wall_height": 2.5,
                "openings": [{"kind": "window", "width": 1.5, "height": 1.5}],
            }]
        }
        self.assertAlmostEqual(
            apartment_from_scene(surowe).rooms[0].takeoff.skirting_m, 14.0
        )


class TestWczytywanie(unittest.TestCase):
    def test_przykladowe_mieszkanie(self):
        m = apartment_from_scene(scena())
        self.assertEqual(len(m.rooms), 5)
        self.assertAlmostEqual(m.floor_area_m2, 59.5725, places=3)
        self.assertEqual(m.doors, 4)      # wejsciowe + 3 wewnetrzne, nie 8
        self.assertEqual(m.windows, 5)

    def test_scena_jednopokojowa_tez_przechodzi(self):
        with open(DATA / "scene.example.json", encoding="utf-8") as handle:
            m = apartment_from_scene(json.load(handle))
        self.assertEqual(len(m.rooms), 1)
        self.assertAlmostEqual(m.floor_area_m2, 24.0)

    def test_typ_domyslny_gdy_scena_go_nie_podaje(self):
        m = apartment_from_scene(
            {"rooms": [{"id": "x", "outline": [[0, 0], [2, 0], [2, 2], [0, 2]],
                        "wall_height": 2.5}]}
        )
        self.assertEqual(m.rooms[0].type, "*")

    def test_zduplikowany_identyfikator(self):
        with self.assertRaises(TakeoffError):
            apartment_from_scene({
                "rooms": [
                    {"id": "x", "outline": [[0, 0], [2, 0], [2, 2], [0, 2]], "wall_height": 2.5},
                    {"id": "x", "outline": [[3, 0], [5, 0], [5, 2], [3, 2]], "wall_height": 2.5},
                ]
            })

    def test_nieznane_pomieszczenie(self):
        with self.assertRaises(TakeoffError):
            dwa_pokoje().by_id("kuchnia")


class TestMaterialWedlugTypuPomieszczenia(unittest.TestCase):
    def setUp(self):
        self.catalog = load_catalog(DATA / "catalog.example.json")
        self.m = apartment_from_scene(scena())

    def test_lazienka_dostaje_plytke_a_salon_farbe(self):
        pakiet = self.catalog.packages["standard"]
        self.assertEqual(pakiet.surfaces_for("salon")["wall"], "farba.sciana.biel")
        self.assertEqual(
            pakiet.surfaces_for("lazienka")["wall"], "cersanit.plytka.calm-colours"
        )

    def test_typ_bez_nadpisania_dostaje_domyslne(self):
        pakiet = self.catalog.packages["standard"]
        self.assertEqual(
            pakiet.surfaces_for("sypialnia"), pakiet.surfaces_for("*")
        )

    def test_pusta_wartosc_znaczy_brak_pozycji(self):
        """W lazience nie ma listwy przypodlogowej - i nie ma jej tez
        w wycenie, zamiast wchodzic tam za zero zlotych."""
        pakiet = self.catalog.packages["standard"]
        self.assertEqual(pakiet.surfaces_for("lazienka")["skirting"], "")
        quote = quote_room(self.catalog, pakiet, self.m.by_id("lazienka"))
        self.assertFalse(any("listwa" in l.item_id for l in quote.lines))

    def test_salon_ma_listwe(self):
        quote = quote_room(
            self.catalog, self.catalog.packages["standard"], self.m.by_id("salon")
        )
        self.assertTrue(any("listwa" in l.item_id for l in quote.lines))

    def test_premium_zmienia_material_w_kazdym_typie(self):
        std = self.catalog.packages["standard"]
        prem = self.catalog.packages["premium"]
        self.assertNotEqual(std.surfaces_for("salon")["floor"], prem.surfaces_for("salon")["floor"])
        self.assertNotEqual(std.surfaces_for("lazienka")["wall"], prem.surfaces_for("lazienka")["wall"])


class TestWycenaMieszkania(unittest.TestCase):
    def setUp(self):
        self.catalog = load_catalog(DATA / "catalog.example.json")
        self.m = apartment_from_scene(scena())
        self.q = quote_apartment(self.catalog, self.catalog.packages["standard"], self.m)

    def test_wycena_ma_pozycje_w_kazdym_pomieszczeniu(self):
        self.assertEqual(set(self.q.per_room), {r.id for r in self.m.rooms})

    def test_drzwi_sa_we_wspolnych_i_w_liczbie_unikalnej(self):
        drzwi = next(
            l for l in self.q.shared.lines if l.item_id == "porta.drzwi.verte-home"
        )
        self.assertAlmostEqual(drzwi.quantity_billed, 4.0)

    def test_suma_to_pomieszczenia_plus_wspolne(self):
        recznie = sum(q.net for q in self.q.per_room.values()) + self.q.shared.net
        self.assertAlmostEqual(self.q.net, recznie, places=2)

    def test_brutto_rowne_netto_plus_vat(self):
        self.assertAlmostEqual(self.q.gross, self.q.net + self.q.vat, places=2)

    def test_przykladowe_pakiety_sa_robocze(self):
        for quote in quote_all_packages_for_apartment(self.catalog, self.m):
            self.assertFalse(quote.sendable, quote.package_id)

    def test_zastrzezenia_sie_nie_powtarzaja(self):
        self.assertEqual(len(self.q.warnings), len(set(self.q.warnings)))

    def test_wydruk_wymienia_pomieszczenia(self):
        tekst = self.q.as_text()
        for room in self.m.rooms:
            self.assertIn(room.id, tekst)

    def test_wycena_bez_zastrzezen_jest_do_wyslania(self):
        raw = {
            "schema_version": 1, "currency": "PLN",
            "items": [{
                "id": "p.podloga", "kind": "material", "name": "Podloga",
                "brand": "Test", "surface": "floor", "unit": "m2",
                "waste_factor": 0.0,
                "price": {"net": 100.0, "vat_rate": 0.23, "status": "listed",
                          "date": "2026-09-06"},
                "provenance": {"source_url": "https://example.invalid/p",
                               "license": "written_consent"},
            }],
            "packages": [{"id": "p", "name": "P", "surfaces": {"floor": "p.podloga"}}],
        }
        catalog = catalog_from_dict(raw)
        quote = quote_apartment(catalog, catalog.packages["p"], dwa_pokoje())
        self.assertTrue(quote.sendable)
        # 24 m2 * 100 zl
        self.assertAlmostEqual(quote.net, 2400.0)


if __name__ == "__main__":
    unittest.main()

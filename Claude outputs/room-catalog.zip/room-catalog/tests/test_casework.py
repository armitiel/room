"""Testy zabudowy parametrycznej.

Rozkroj pojedynczej szafki policzony recznie w komentarzach - to jedyny
sposob, zeby test wykryl blad we wzorze, a nie tylko powtorzyl go za kodem.
"""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from catalog.casework import (  # noqa: E402
    MIN_MODULE_MM,
    STANDARD_WIDTHS_MM,
    Bom,
    CaseworkError,
    CaseworkKit,
    Module,
    bom_for_module,
    bom_for_run,
    bom_for_runs,
    default_module,
    describe_run,
    load_kits,
    plan_run,
    quote_casework,
)
from catalog.model import CatalogError, catalog_from_dict, load_catalog  # noqa: E402

DATA = Path(__file__).resolve().parents[1] / "data"


class TestModul(unittest.TestCase):
    def test_domyslne_wymiary_szafki_dolnej(self):
        m = default_module("base", 600)
        self.assertEqual((m.height_mm, m.depth_mm), (720, 560))

    def test_domyslne_wymiary_szafki_gornej(self):
        m = default_module("wall", 600)
        self.assertEqual((m.height_mm, m.depth_mm), (720, 320))

    def test_szeroki_modul_dostaje_dwa_skrzydla(self):
        self.assertEqual(default_module("base", 600).doors, 1)
        self.assertEqual(default_module("base", 800).doors, 2)

    def test_swiatlo_korpusu(self):
        # 600 - 2 * 18 mm plyty = 564
        self.assertEqual(default_module("base", 600).interior_width_mm, 564)

    def test_nieznany_rodzaj(self):
        with self.assertRaises(CaseworkError):
            default_module("antresola", 600)

    def test_modul_wezszy_niz_minimum(self):
        with self.assertRaises(CaseworkError):
            default_module("base", 200)

    def test_ujemna_liczba_frontow(self):
        with self.assertRaises(CaseworkError):
            Module("base", 600, 720, 560, doors=-1).validate()


class TestZawiasy(unittest.TestCase):
    def test_niski_front_dwa_zawiasy(self):
        # front 720 - 3 = 717 mm, ponizej progu 900
        self.assertEqual(default_module("base", 600).hinges(), 2)

    def test_szafa_pelnej_wysokosci_piec_zawiasow_na_skrzydlo(self):
        # front 2100 - 3 = 2097 mm, przedzial do 2400 -> 5 zawiasow
        szafa = default_module("tall", 900)  # 900 > 700, wiec dwa skrzydla
        self.assertEqual(szafa.doors, 2)
        self.assertEqual(szafa.hinges(), 10)

    def test_komoda_bez_drzwi_nie_ma_zawiasow(self):
        komoda = default_module("base", 600, doors=0, drawers=3)
        self.assertEqual(komoda.hinges(), 0)

    def test_uchwyt_na_kazdy_front_i_szuflade(self):
        self.assertEqual(default_module("base", 800).handles(), 2)
        self.assertEqual(default_module("base", 600, doors=0, drawers=3).handles(), 3)


class TestRozkrojSzafki(unittest.TestCase):
    """Szafka dolna 600 x 720 x 560, jedno skrzydlo, jedna polka.

    boki      2 x (720 x 560)          =   806 400 mm2
    wiencie   2 x (564 x 560)          =   631 680 mm2
    polka     1 x (564 x 540)          =   304 560 mm2
    korpus                              = 1 742 640 mm2 = 1,742640 m2
    plecy     600 x 720                =   432 000 mm2 = 0,432000 m2
    front     597 x 717                =   428 049 mm2 = 0,428049 m2
    obrzeze   2 x (597 + 717) + 564    =     3 192 mm  = 3,192 m
    """

    def setUp(self):
        self.bom = bom_for_module(default_module("base", 600))

    def test_korpus(self):
        self.assertAlmostEqual(self.bom.board_carcass_m2, 1.742640, places=6)

    def test_plecy(self):
        self.assertAlmostEqual(self.bom.board_back_m2, 0.432000, places=6)

    def test_front(self):
        self.assertAlmostEqual(self.bom.board_front_m2, 0.428049, places=6)

    def test_obrzeze(self):
        self.assertAlmostEqual(self.bom.edge_banding_m, 3.192, places=6)

    def test_okucia(self):
        self.assertEqual(self.bom.hinge, 2)
        self.assertEqual(self.bom.handle, 1)
        self.assertEqual(self.bom.drawer_slide, 0)

    def test_blat_i_cokol_tylko_dla_dolnej(self):
        self.assertAlmostEqual(self.bom.worktop_m, 0.6)
        self.assertAlmostEqual(self.bom.plinth_m, 0.6)

    def test_gorna_szafka_nie_ma_blatu_ani_cokolu(self):
        gorna = bom_for_module(default_module("wall", 600))
        self.assertAlmostEqual(gorna.worktop_m, 0.0)
        self.assertAlmostEqual(gorna.plinth_m, 0.0)

    def test_polka_cofnieta_od_frontu(self):
        """Polka jest plytsza od korpusu o SHELF_SETBACK_MM, zeby nie
        kolidowala z zawiasem. Bez tego korpus wyszedlby wiekszy."""
        bez_polki = bom_for_module(default_module("base", 600, shelves=0))
        roznica = self.bom.board_carcass_m2 - bez_polki.board_carcass_m2
        self.assertAlmostEqual(roznica, (564 * 540) / 1_000_000, places=6)


class TestRozkrojKomody(unittest.TestCase):
    """Komoda 600, trzy szuflady, bez drzwi.

    front szuflady 597 x 239, trzy sztuki = 428 049 mm2 = 0,428049 m2
    obrzeze 3 x 2 x (597 + 239) + 564    =   5 580 mm  = 5,580 m
    """

    def setUp(self):
        self.bom = bom_for_module(default_module("base", 600, doors=0, drawers=3))

    def test_fronty_szuflad(self):
        self.assertAlmostEqual(self.bom.board_front_m2, 0.428049, places=6)

    def test_obrzeze(self):
        self.assertAlmostEqual(self.bom.edge_banding_m, 5.580, places=6)

    def test_prowadnice_na_kazda_szuflade(self):
        self.assertEqual(self.bom.drawer_slide, 3)


class TestPodzialOdcinka(unittest.TestCase):
    def test_dokladny_podzial_trzech_metrow(self):
        run = plan_run("kuchnia", "base", 3000)
        self.assertEqual(run.modules_width_mm, 3000)
        self.assertEqual(run.filler_mm, 0)
        self.assertEqual(len(run.modules), 4)  # 900 to maksimum, wiec 3 za malo

    def test_minimalna_liczba_modulow(self):
        """1800 da sie zlozyc z dwoch po 900 albo z czterech po 450 -
        generator ma wybrac wariant tanszy w robociznie."""
        run = plan_run("kuchnia", "base", 1800)
        self.assertEqual(len(run.modules), 2)
        self.assertEqual(run.filler_mm, 0)

    def test_przy_rownej_liczbie_szafek_wybiera_rowniejszy_ciag(self):
        """3000 mm da sie zlozyc jako 900+900+900+300 albo 800+800+800+600 -
        obie po cztery szafki, ale druga wersja wyglada jak zabudowa,
        a nie jak zabudowa z doklejka."""
        run = plan_run("kuchnia", "base", 3000)
        widths = sorted(m.width_mm for m in run.modules)
        self.assertEqual(len(run.modules), 4)
        self.assertLessEqual(max(widths) - min(widths), 200)

    def test_rowny_odcinek_dzieli_sie_na_jednakowe_moduly(self):
        run = plan_run("kuchnia", "base", 5600)
        self.assertEqual({m.width_mm for m in run.modules}, {800})

    def test_reszta_idzie_na_blende(self):
        # 350 mm: miesci sie tylko modul 300, zostaje 50 mm blendy
        run = plan_run("kuchnia", "base", 350)
        self.assertEqual(len(run.modules), 1)
        self.assertEqual(run.modules[0].width_mm, 300)
        self.assertEqual(run.filler_mm, 50)

    def test_odcinek_krotszy_niz_modul(self):
        run = plan_run("kuchnia", "base", 250)
        self.assertEqual(run.modules, ())
        self.assertEqual(run.filler_mm, 250)

    def test_suma_modulow_i_blendy_rowna_dlugosci(self):
        for length in (350, 900, 1234, 2600, 3000, 4750, 6000):
            run = plan_run("x", "base", length)
            self.assertEqual(
                run.modules_width_mm + run.filler_mm,
                length,
                f"nie domyka sie dla {length} mm",
            )

    def test_wszystkie_moduly_ze_slownika_szerokosci(self):
        run = plan_run("x", "base", 4750)
        for module in run.modules:
            self.assertIn(module.width_mm, STANDARD_WIDTHS_MM)
            self.assertGreaterEqual(module.width_mm, MIN_MODULE_MM)

    def test_nadpisanie_pojedynczego_modulu(self):
        run = plan_run("kuchnia", "base", 1800, module_overrides={0: {"doors": 0, "drawers": 3}})
        self.assertEqual(run.modules[0].drawers, 3)
        self.assertEqual(run.modules[1].drawers, 0)

    def test_ujemna_dlugosc(self):
        with self.assertRaises(CaseworkError):
            plan_run("x", "base", -100)

    def test_opis_ciagu(self):
        opis = describe_run(plan_run("kuchnia", "base", 350))
        self.assertIn("350 mm", opis)
        self.assertIn("blenda 50 mm", opis)


class TestRozkrojCiagu(unittest.TestCase):
    def test_blat_na_cala_dlugosc_ciagu(self):
        """Blat i cokol ida po calym odcinku, razem z blenda."""
        run = plan_run("kuchnia", "base", 3050)
        bom = bom_for_run(run)
        self.assertAlmostEqual(bom.worktop_m, 3.05, places=6)
        self.assertAlmostEqual(bom.plinth_m, 3.05, places=6)

    def test_blenda_wchodzi_we_fronty(self):
        run = plan_run("kuchnia", "base", 350)  # 300 + 50 blendy
        bom = bom_for_run(run)
        sam_modul = bom_for_module(run.modules[0])
        roznica = bom.board_front_m2 - sam_modul.board_front_m2
        self.assertAlmostEqual(roznica, (50 * 720) / 1_000_000, places=6)

    def test_sumowanie_kilku_ciagow(self):
        dolne = plan_run("dolne", "base", 3000)
        gorne = plan_run("gorne", "wall", 3000)
        razem = bom_for_runs([dolne, gorne])
        self.assertAlmostEqual(
            razem.board_carcass_m2,
            bom_for_run(dolne).board_carcass_m2 + bom_for_run(gorne).board_carcass_m2,
            places=9,
        )
        # blat tylko od dolnych
        self.assertAlmostEqual(razem.worktop_m, 3.0, places=6)

    def test_nieznana_rola(self):
        with self.assertRaises(CaseworkError):
            Bom().quantity_for_role("sufit")


class TestWycenaZabudowy(unittest.TestCase):
    def setUp(self):
        self.catalog = load_catalog(DATA / "catalog.example.json")
        self.kits = load_kits(DATA / "catalog.example.json")
        self.kit = self.kits["kuchnia.standard"]
        self.bom = bom_for_run(plan_run("kuchnia", "base", 3000))

    def test_zestaw_z_przykladowego_katalogu_jest_kompletny(self):
        self.assertEqual(self.kit.validate(self.catalog.items), [])

    def test_wycena_ma_pozycje_na_kazda_role_z_niezerowym_przedmiarem(self):
        quote = quote_casework(self.catalog, self.kit, self.bom)
        role_ids = {line.item_id for line in quote.lines}
        self.assertIn("plyta.korpus.18", role_ids)
        self.assertIn("okucie.zawias", role_ids)
        self.assertIn("blat.laminowany.38", role_ids)

    def test_rola_bez_przedmiaru_nie_tworzy_pozycji(self):
        # ciag bez szuflad nie ma prowadnic
        quote = quote_casework(self.catalog, self.kit, self.bom)
        self.assertNotIn(
            "okucie.prowadnica", {line.item_id for line in quote.lines}
        )

    def test_ubytek_plyty_doliczony(self):
        quote = quote_casework(self.catalog, self.kit, self.bom)
        korpus = next(l for l in quote.lines if l.item_id == "plyta.korpus.18")
        self.assertAlmostEqual(
            korpus.quantity_billed, korpus.quantity_raw * 1.15, places=6
        )

    def test_okucia_bez_ubytku(self):
        quote = quote_casework(self.catalog, self.kit, self.bom)
        zawiasy = next(l for l in quote.lines if l.item_id == "okucie.zawias")
        self.assertAlmostEqual(zawiasy.quantity_billed, zawiasy.quantity_raw)

    def test_bramka_licencyjna_blokuje_tak_samo_jak_reszte(self):
        quote = quote_casework(self.catalog, self.kit, self.bom)
        self.assertFalse(quote.sendable)
        self.assertTrue(any("designer_zone" in w for w in quote.warnings))

    def test_brak_roli_w_zestawie_daje_zastrzezenie(self):
        okrojony = CaseworkKit(
            id="okrojony",
            name="Bez blatu",
            roles={k: v for k, v in self.kit.roles.items() if k != "worktop"},
        )
        quote = quote_casework(self.catalog, okrojony, self.bom)
        self.assertTrue(any("blat" in w and "nie ma tej pozycji" in w for w in quote.warnings))

    def test_zestaw_wskazujacy_zla_role(self):
        zly = CaseworkKit(
            id="zly", name="Zly", roles={"hinge": "plyta.korpus.18"}
        )
        with self.assertRaises(CatalogError):
            quote_casework(self.catalog, zly, self.bom)

    def test_zestaw_wskazujacy_material_zamiast_komponentu(self):
        zly = CaseworkKit(
            id="zly", name="Zly", roles={"board_carcass": "vox.podloga.dab-natur"}
        )
        with self.assertRaises(CatalogError):
            quote_casework(self.catalog, zly, self.bom)

    def test_kwoty_sumuja_sie_po_pozycjach(self):
        quote = quote_casework(self.catalog, self.kit, self.bom)
        self.assertAlmostEqual(quote.net, sum(l.net for l in quote.lines))


class TestKontraktKomponentu(unittest.TestCase):
    def _raw(self, **nadpisz):
        item = {
            "id": "plyta.test",
            "kind": "component",
            "name": "Plyta",
            "brand": "Test",
            "role": "board_carcass",
            "unit": "m2",
            "waste_factor": 0.15,
            "price": {
                "net": 50.0,
                "vat_rate": 0.23,
                "status": "listed",
                "date": "2026-09-06",
            },
            "provenance": {
                "source_url": "https://example.invalid/plyta",
                "license": "written_consent",
            },
        }
        item.update(nadpisz)
        return {"schema_version": 1, "currency": "PLN", "items": [item], "packages": []}

    def test_poprawny_komponent(self):
        self.assertEqual(catalog_from_dict(self._raw()).validate(), [])

    def test_rola_spoza_slownika(self):
        errs = catalog_from_dict(self._raw(role="zawias-magiczny")).validate()
        self.assertTrue(any("role=" in e for e in errs))

    def test_jednostka_niezgodna_z_rola(self):
        """Zawias w metrach kwadratowych to najlatwiejsza pomylka w tym pliku."""
        errs = catalog_from_dict(self._raw(role="hinge", unit="m2")).validate()
        self.assertTrue(any("rozlicza sie w szt" in e for e in errs))

    def test_komponent_nie_moze_miec_powierzchni(self):
        errs = catalog_from_dict(self._raw(surface="floor")).validate()
        self.assertTrue(any("nie moze miec surface" in e for e in errs))

    def test_material_nie_moze_miec_roli(self):
        raw = self._raw()
        raw["items"][0].update(kind="material", surface="floor", role="board_carcass")
        errs = catalog_from_dict(raw).validate()
        self.assertTrue(any("nie moze miec role" in e for e in errs))

    def test_komponent_nie_wymaga_pliku_modelu(self):
        item = catalog_from_dict(self._raw()).items["plyta.test"]
        self.assertEqual(item.blockers(), [])
        self.assertTrue(item.client_safe)


if __name__ == "__main__":
    unittest.main()


class TestBrylyDoSceny(unittest.TestCase):
    def setUp(self):
        from catalog.casework import boxes_for_run

        self.boxes_for_run = boxes_for_run
        self.run = plan_run("kuchnia", "base", 1800)  # 2 x 900

    def test_kazdy_modul_dostaje_bryle_plus_blat(self):
        boxes = self.boxes_for_run(self.run)
        self.assertEqual(len(boxes), len(self.run.modules) + 1)
        self.assertEqual(boxes[-1]["kind"], "worktop")

    def test_moduly_ustawione_kolejno_wzdluz_osi_x(self):
        boxes = self.boxes_for_run(self.run)
        self.assertAlmostEqual(boxes[0]["x_mm"], 450.0)   # srodek pierwszej 900
        self.assertAlmostEqual(boxes[1]["x_mm"], 1350.0)  # srodek drugiej
        self.assertAlmostEqual(boxes[0]["y_mm"], 0.0)

    def test_obrot_o_dziewiecdziesiat_stopni_klada_ciag_wzdluz_y(self):
        boxes = self.boxes_for_run(self.run, direction_deg=90.0)
        self.assertAlmostEqual(boxes[0]["x_mm"], 0.0, places=6)
        self.assertAlmostEqual(boxes[0]["y_mm"], 450.0)

    def test_przesuniecie_poczatku(self):
        boxes = self.boxes_for_run(self.run, origin_mm=(1000.0, 500.0))
        self.assertAlmostEqual(boxes[0]["x_mm"], 1450.0)
        self.assertAlmostEqual(boxes[0]["y_mm"], 500.0)

    def test_szafki_dolne_stoja_na_cokole(self):
        boxes = self.boxes_for_run(self.run)
        self.assertEqual(boxes[0]["z_mm"], 100)

    def test_blat_lezy_na_korpusach(self):
        # cokol 100 + korpus 720 = 820 mm
        boxes = self.boxes_for_run(self.run)
        self.assertEqual(boxes[-1]["z_mm"], 820)
        self.assertAlmostEqual(boxes[-1]["width_mm"], 1800)

    def test_szafki_gorne_wisza_nad_blatem(self):
        gorne = plan_run("gorne", "wall", 1800)
        boxes = self.boxes_for_run(gorne)
        self.assertEqual(boxes[0]["z_mm"], 1450)
        self.assertTrue(all(b["kind"] != "worktop" for b in boxes))

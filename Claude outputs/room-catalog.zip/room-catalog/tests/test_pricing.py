"""Testy wyceny. Kwoty policzone recznie w komentarzach."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from catalog.model import catalog_from_dict, load_catalog  # noqa: E402
from catalog.pricing import quote_all_packages, quote_package  # noqa: E402
from catalog.takeoff import Opening, compute_takeoff, takeoff_from_scene  # noqa: E402

DATA = Path(__file__).resolve().parents[1] / "data"

PROSTOKAT = [(0.0, 0.0), (5.0, 0.0), (5.0, 4.0), (0.0, 4.0)]  # 20 m2, obwod 18 m


def raw_catalog(**nadpisz) -> dict:
    base = {
        "schema_version": 1,
        "currency": "PLN",
        "items": [
            {
                "id": "p.podloga",
                "kind": "material",
                "name": "Podloga",
                "brand": "Test",
                "surface": "floor",
                "unit": "m2",
                "waste_factor": 0.10,
                "price": {
                    "net": 100.0,
                    "vat_rate": 0.23,
                    "status": "listed",
                    "date": "2026-09-06",
                },
                "provenance": {
                    "source_url": "https://example.invalid/p",
                    "license": "written_consent",
                },
            },
            {
                "id": "p.drzwi",
                "kind": "object",
                "name": "Drzwi",
                "brand": "Test",
                "slot": "door",
                "anchor": "opening",
                "unit": "szt",
                "dimensions_mm": {"w": 800, "d": 40, "h": 2030},
                "model": "models/d.glb",
                "price": {
                    "net": 1000.0,
                    "vat_rate": 0.23,
                    "status": "listed",
                    "date": "2026-09-06",
                },
                "provenance": {
                    "source_url": "https://example.invalid/d",
                    "license": "written_consent",
                },
            },
        ],
        "packages": [
            {
                "id": "podstawowy",
                "name": "Podstawowy",
                "surfaces": {"floor": "p.podloga"},
                "from_takeoff": {"p.drzwi": "doors"},
            }
        ],
    }
    base.update(nadpisz)
    return base


class TestWycena(unittest.TestCase):
    def setUp(self):
        self.catalog = catalog_from_dict(raw_catalog())
        self.takeoff = compute_takeoff(
            PROSTOKAT, 2.7, [Opening("door", 0.9, 2.05), Opening("door", 0.9, 2.05)]
        )
        self.quote = quote_package(
            self.catalog, self.catalog.packages["podstawowy"], self.takeoff
        )

    def test_ubytek_doliczony_do_ilosci(self):
        # 20 m2 * 1,10 = 22 m2
        podloga = next(l for l in self.quote.lines if l.item_id == "p.podloga")
        self.assertAlmostEqual(podloga.quantity_raw, 20.0)
        self.assertAlmostEqual(podloga.quantity_billed, 22.0)

    def test_kwota_netto_pozycji(self):
        # 22 m2 * 100 zl = 2 200 zl
        podloga = next(l for l in self.quote.lines if l.item_id == "p.podloga")
        self.assertAlmostEqual(podloga.net, 2200.00)

    def test_vat_pozycji(self):
        # 2 200 * 0,23 = 506
        podloga = next(l for l in self.quote.lines if l.item_id == "p.podloga")
        self.assertAlmostEqual(podloga.vat, 506.00)
        self.assertAlmostEqual(podloga.gross, 2706.00)

    def test_ilosc_drzwi_z_przedmiaru(self):
        drzwi = next(l for l in self.quote.lines if l.item_id == "p.drzwi")
        self.assertAlmostEqual(drzwi.quantity_billed, 2.0)
        self.assertAlmostEqual(drzwi.net, 2000.00)

    def test_obiekt_nie_dostaje_ubytku(self):
        drzwi = next(l for l in self.quote.lines if l.item_id == "p.drzwi")
        self.assertAlmostEqual(drzwi.waste_factor, 0.0)

    def test_suma_calosci(self):
        # netto 2 200 + 2 000 = 4 200; VAT 966; brutto 5 166
        self.assertAlmostEqual(self.quote.net, 4200.00)
        self.assertAlmostEqual(self.quote.vat, 966.00)
        self.assertAlmostEqual(self.quote.gross, 5166.00)

    def test_suma_brutto_rowna_sumie_pozycji(self):
        self.assertAlmostEqual(
            self.quote.gross, sum(l.gross for l in self.quote.lines)
        )

    def test_wycena_bez_zastrzezen_jest_do_wyslania(self):
        self.assertEqual(self.quote.warnings, ())
        self.assertTrue(self.quote.sendable)

    def test_zero_sztuk_nie_tworzy_pozycji(self):
        raw = raw_catalog()
        raw["packages"][0]["objects"] = {"p.drzwi": 0}
        catalog = catalog_from_dict(raw)
        quote = quote_package(catalog, catalog.packages["podstawowy"], self.takeoff)
        # drzwi pojawiaja sie tylko raz, z from_takeoff
        self.assertEqual(sum(1 for l in quote.lines if l.item_id == "p.drzwi"), 1)


class TestZastrzezenia(unittest.TestCase):
    def setUp(self):
        self.takeoff = compute_takeoff(PROSTOKAT, 2.7, [Opening("door", 0.9, 2.05)])

    def _quote(self, raw):
        catalog = catalog_from_dict(raw)
        return quote_package(catalog, catalog.packages["podstawowy"], self.takeoff)

    def test_cena_placeholder_blokuje_wysylke(self):
        raw = raw_catalog()
        raw["items"][0]["price"]["status"] = "placeholder"
        quote = self._quote(raw)
        self.assertFalse(quote.sendable)
        self.assertTrue(any("placeholder" in w for w in quote.warnings))

    def test_licencja_bez_zgody_blokuje_wysylke(self):
        raw = raw_catalog()
        raw["items"][0]["provenance"]["license"] = "designer_zone"
        quote = self._quote(raw)
        self.assertFalse(quote.sendable)
        self.assertTrue(any("designer_zone" in w for w in quote.warnings))

    def test_brak_modelu_blokuje_wysylke(self):
        raw = raw_catalog()
        raw["items"][1]["model"] = ""
        quote = self._quote(raw)
        self.assertFalse(quote.sendable)
        self.assertTrue(any("modelu" in w for w in quote.warnings))

    def test_zastrzezenia_sie_nie_powtarzaja(self):
        raw = raw_catalog()
        raw["items"][0]["price"]["status"] = "placeholder"
        raw["packages"][0]["objects"] = {"p.podloga": 1}
        # ta sama pozycja moglaby trafic dwa razy; zastrzezenie ma byc jedno
        quote = self._quote(raw)
        self.assertEqual(len(quote.warnings), len(set(quote.warnings)))

    def test_kwoty_licza_sie_mimo_zastrzezen(self):
        """Kalkulacja robocza ma pokazywac liczby - blokada dotyczy wysylki."""
        raw = raw_catalog()
        raw["items"][0]["provenance"]["license"] = "designer_zone"
        quote = self._quote(raw)
        self.assertGreater(quote.gross, 0.0)


class TestNaPrzykladowychDanych(unittest.TestCase):
    def setUp(self):
        import json

        with open(DATA / "scene.example.json", encoding="utf-8") as handle:
            self.takeoff = takeoff_from_scene(json.load(handle))
        self.catalog = load_catalog(DATA / "catalog.example.json")

    def test_katalog_przykladowy_daje_trzy_pakiety(self):
        quotes = quote_all_packages(self.catalog, self.takeoff)
        self.assertEqual(
            [q.package_id for q in quotes], ["comfort", "premium", "standard"]
        )

    def test_zaden_przykladowy_pakiet_nie_jest_do_wyslania(self):
        for quote in quote_all_packages(self.catalog, self.takeoff):
            self.assertFalse(quote.sendable, quote.package_id)

    def test_pakiet_standard_ma_pozycje_drzwi_w_ilosci_dwa(self):
        quote = quote_package(
            self.catalog, self.catalog.packages["standard"], self.takeoff
        )
        drzwi = next(l for l in quote.lines if l.item_id == "porta.drzwi.verte-home")
        self.assertAlmostEqual(drzwi.quantity_billed, 2.0)

    def test_podloga_liczona_z_ubytkiem_siedem_procent(self):
        quote = quote_package(
            self.catalog, self.catalog.packages["standard"], self.takeoff
        )
        podloga = next(l for l in quote.lines if l.item_id.startswith("vox.podloga"))
        self.assertAlmostEqual(podloga.quantity_raw, 24.0)
        self.assertAlmostEqual(podloga.quantity_billed, 25.68)  # 24 * 1,07

    def test_material_scienny_liczony_z_powierzchni_netto(self):
        """Pakiet bez podzialu na pomieszczenia uzywa wpisu domyslnego,
        a tam sciana jest malowana - plytka wchodzi dopiero w lazience."""
        quote = quote_package(
            self.catalog, self.catalog.packages["standard"], self.takeoff
        )
        farba = next(l for l in quote.lines if l.item_id == "farba.sciana.biel")
        self.assertAlmostEqual(farba.quantity_raw, 56.91)
        self.assertAlmostEqual(farba.quantity_billed, 59.7555)  # 56,91 * 1,05


if __name__ == "__main__":
    unittest.main()

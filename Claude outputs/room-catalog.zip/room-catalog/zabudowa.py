#!/usr/bin/env python3
"""Zaplanuj i wycen zabudowe parametryczna.

    python3 zabudowa.py data/catalog.example.json kuchnia.standard \\
        dolne:base:3000 gorne:wall:3000 szafa:tall:2400

Ciag opisuje sie jako nazwa:rodzaj:dlugosc_mm, gdzie rodzaj to base
(szafki dolne), wall (gorne) albo tall (slupki i szafy).

Opcjonalnie --bryly zapisuje bryly modulow do pliku JSON, gotowe do
wstawienia do sceny.

Pod Blenderem:

    blender --background --python zabudowa.py -- katalog.json zestaw ciag...
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from catalog import load_catalog  # noqa: E402
from catalog.casework import (  # noqa: E402
    CaseworkError,
    bom_for_runs,
    boxes_for_run,
    describe_run,
    load_kits,
    plan_run,
    quote_casework,
)


def _args() -> list[str]:
    argv = sys.argv
    if "--" in argv:
        return argv[argv.index("--") + 1 :]
    return argv[1:]


def _parse_run(spec: str):
    parts = spec.split(":")
    if len(parts) != 3:
        raise CaseworkError(
            f"ciag {spec!r} ma zly format; oczekiwano nazwa:rodzaj:dlugosc_mm"
        )
    name, kind, length = parts
    if not length.isdigit():
        raise CaseworkError(f"dlugosc {length!r} w ciagu {name!r} nie jest liczba mm")
    return plan_run(name, kind, int(length))


def main() -> int:
    args = _args()
    boxes_path = None
    if "--bryly" in args:
        index = args.index("--bryly")
        try:
            boxes_path = args[index + 1]
        except IndexError:
            print("--bryly wymaga sciezki pliku")
            return 2
        args = args[:index] + args[index + 2 :]

    if len(args) < 3:
        print(__doc__)
        return 2

    catalog_path, kit_id, *run_specs = args

    catalog = load_catalog(catalog_path)
    catalog.require_valid()

    kits = load_kits(catalog_path)
    if kit_id not in kits:
        print(f"nie znam zestawu {kit_id!r}; dostepne: {', '.join(sorted(kits)) or 'brak'}")
        return 2
    kit = kits[kit_id]

    runs = [_parse_run(spec) for spec in run_specs]

    print("PODZIAL NA MODULY")
    for run in runs:
        print("  " + describe_run(run))
    total_modules = sum(len(run.modules) for run in runs)
    print(f"  razem {total_modules} szafek")
    print()

    bom = bom_for_runs(runs)
    print("ROZKROJ")
    print(f"  plyta korpusowa    {bom.board_carcass_m2:8.2f} m2")
    print(f"  fronty             {bom.board_front_m2:8.2f} m2")
    print(f"  plecy HDF          {bom.board_back_m2:8.2f} m2")
    print(f"  obrzeze            {bom.edge_banding_m:8.2f} mb")
    print(f"  blat               {bom.worktop_m:8.2f} mb")
    print(f"  cokol              {bom.plinth_m:8.2f} mb")
    print(f"  zawiasy            {bom.hinge:8d} szt")
    print(f"  prowadnice         {bom.drawer_slide:8d} kpl")
    print(f"  uchwyty            {bom.handle:8d} szt")
    print()

    quote = quote_casework(catalog, kit, bom, label=kit.name)
    print(quote.as_text())

    if boxes_path:
        boxes = []
        for run in runs:
            boxes += boxes_for_run(run)
        with open(boxes_path, "w", encoding="utf-8") as handle:
            json.dump({"casework": boxes}, handle, ensure_ascii=False, indent=2)
        print()
        print(f"Bryly zapisane do {boxes_path} ({len(boxes)} elementow).")

    return 0 if quote.sendable else 1


if __name__ == "__main__":
    raise SystemExit(main())

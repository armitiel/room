#!/usr/bin/env python3
"""Policz wycene pakietow dla sceny.

    python3 wycen.py data/scene.example.json data/catalog.example.json

Dziala tez pod pythonem z Blendera:

    blender --background --python wycen.py -- scena.json katalog.json
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from catalog import load_catalog, quote_all_packages, takeoff_from_scene  # noqa: E402


def _args() -> list[str]:
    # Pod Blenderem argumenty skryptu ida po "--".
    argv = sys.argv
    if "--" in argv:
        return argv[argv.index("--") + 1 :]
    return argv[1:]


def main() -> int:
    args = _args()
    if len(args) != 2:
        print(__doc__)
        return 2

    scene_path, catalog_path = args

    with open(scene_path, "r", encoding="utf-8") as handle:
        scene = json.load(handle)

    takeoff = takeoff_from_scene(scene)
    catalog = load_catalog(catalog_path)
    catalog.require_valid()

    print("PRZEDMIAR")
    print(f"  podloga / sufit    {takeoff.floor_area_m2:8.2f} m2")
    print(f"  sciany brutto      {takeoff.wall_area_gross_m2:8.2f} m2")
    print(f"  sciany netto       {takeoff.wall_area_net_m2:8.2f} m2")
    print(f"  obwod              {takeoff.perimeter_m:8.2f} m")
    print(f"  listwy             {takeoff.skirting_m:8.2f} m")
    print(f"  drzwi / okna       {takeoff.doors:8d} / {takeoff.windows}")
    print()

    blocked = 0
    for quote in quote_all_packages(catalog, takeoff):
        print(quote.as_text())
        print()
        if not quote.sendable:
            blocked += 1

    if blocked:
        print(f"{blocked} z pakietow to kalkulacje robocze - nie wolno ich wyslac.")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

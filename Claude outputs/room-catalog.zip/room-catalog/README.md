# Katalog i wycena — moduł do projektu Room

Zamienia obrys pomieszczenia w wycenę pakietu wykończenia. Bez zależności
zewnętrznych, biblioteka standardowa Pythona, więc chodzi też pod interpreterem
z Blendera.

## Gdzie to wgrać

Rozpakować do repo jako `blender/scripts/catalog/` (moduł), `data/` oraz
`wycen.py` i `zabudowa.py` w katalogu głównym. Testy trafiają obok istniejących.

## Uruchomienie

    python3 -m unittest discover -s tests
    python3 wycen.py data/scene.example.json data/catalog.example.json
    python3 zabudowa.py data/catalog.example.json kuchnia.standard \\
        dolne:base:3000 gorne:wall:2400 --bryly bryly.json
    python3 warianty.py data/mieszkanie.example.json data/catalog.example.json \\
        --zabudowa dolne:base:3000:kuchnia --zabudowa gorne:wall:2400:kuchnia \\
        --wyjscie data/variants.json --demo web/warianty-demo.html

Pod Blenderem:

    blender --background --python wycen.py -- scena.json katalog.json

## Sześć modułów

**`catalog/takeoff.py` — przedmiar.** Z obrysu liczy powierzchnię podłogi,
sufitu, ścian brutto i netto, obwód, długość listew i liczbę otworów. Pole
liczone sznurowadłem, więc kierunek zapisu obrysu nie ma znaczenia — to ten sam
błąd, który wcześniej przestawiał otwory na złą stronę ściany. Listwa urywa się
w świetle drzwi, ale nie pod oknem.

Adapter `takeoff_from_scene()` czyta `scene.json`. **Nazwy kluczy są zgadywane**
spośród kilku wariantów (`outline`/`obrys`/`footprint`…) — gdy kontrakt sceny się
ustabilizuje, należy zejść do jednego zestawu. Jednostki: metry. Moduł nie zgaduje
jednostek, jeśli scena trzyma centymetry, trzeba przeliczyć przed wywołaniem.

**`catalog/model.py` — katalog.** Dwa rodzaje pozycji:

- `material` — rozlicza się przez powierzchnię (`m2`) albo długość (`mb`), ma
  przypisaną powierzchnię i współczynnik ubytku na docinanie
- `object` — rozlicza się na sztuki, ma wymiary, punkt osadzenia i plik modelu

Nad nimi `package` — to, czym deweloper faktycznie handluje. Pakiet wskazuje
materiał na każdą powierzchnię, obiekty w stałej ilości oraz obiekty liczone
z przedmiaru (drzwi → `doors`).

**`catalog/pricing.py` — wycena.** Przedmiar × katalog × pakiet. Materiały
dostają ubytek, obiekty nie. Zwraca pozycje, sumy netto/VAT/brutto i listę
zastrzeżeń.

**`catalog/casework.py` — zabudowa parametryczna.** Szafa i kuchnia to bryły
pudełkowe, więc nie trzeba ich skądkolwiek ściągać — da się je policzyć. To
zdejmuje z katalogu największą pozycję wyceny i robi z niej własną geometrię,
bez licencji i bez zgód producenta.

Odcinek ściany → podział na moduły → rozkrój płyty → wycena → bryły do sceny.

Podział to programowanie dynamiczne po milimetrach: minimalizuje liczbę szafek,
a przy remisie wybiera ciąg równiejszy (3000 mm wychodzi jako 600 + 3 × 800,
nie 3 × 900 + 300). Reszta idzie na blendę, która dolicza się do frontów
i blatu. To drugie kryterium jest heurystyką, nie dowodem optymalności.

Rozkrój liczy boki, wieńce, półki cofnięte o 20 mm od frontu, plecy HDF, fronty
z fugą 3 mm, obrzeże po obwodzie frontów i po froncie półek, zawiasy według
progów wysokości, prowadnice na szufladę, uchwyty na front. Rachunek idzie
w milimetrach, przedmiar wychodzi w m², mb i sztukach.

`boxes_for_run()` zwraca bryły modułów i blat w układzie sceny — zabudowa
pojawia się w spacerze, nie tylko na wycenie.

Pozycje zabudowy mają w katalogu własny rodzaj `component` i pole `role`
(`board_carcass`, `edge_banding`, `hinge`, `worktop`…). To nie jest ani
powierzchnia pomieszczenia, ani bryła wstawiana do sceny — to materiał albo
okucie, z którego zabudowa powstaje. Zestaw `casework_kits` mapuje rolę na
pozycję katalogu, a walidator pilnuje, żeby zawias nie trafił do wyceny
w metrach kwadratowych.

**`catalog/variants.py` — warianty.** Kontrakt między generatorem
a przeglądarką, czyli odpowiedź na pytanie „jak wybierać wykończenie w trakcie
spaceru".

Wariant **nie jest drugą sceną**. To ta sama geometria z podmienioną
zawartością gniazd materiałowych. Cztery z nich — `floor`, `wall`, `ceiling`,
`skirting` — rozwiązują się **osobno w każdym pomieszczeniu**; dwa
(`casework_front`, `casework_worktop`) są wspólne, bo układ szafek jest jeden.
Przełączenie to zamiana
materiału na istniejących siatkach — bez ponownego wczytania glTF, bez utraty
pozycji kamery, bez białego błysku. Kupujący idzie przez mieszkanie i naciska
`2`; ściana zmienia się pod nim.

Każdy materiał niesie `module_mm`. To jest miejsce, w którym katalog spotyka
scenę: bez formatu płytki silnik nie wie, ile razy powtórzyć teksturę, i płytka
30 × 90 renderuje się jak tapeta. Przeglądarka liczy `repeat` z realnego
wymiaru płaszczyzny i realnego formatu produktu.

Cena jest policzona **po stronie generatora** i wpisana do wariantu razem
z flagą `draft` i listą `blockers`. Przeglądarka nie liczy pieniędzy — dostaje
kwotę i informację, czy wolno ją pokazać. `client_safe_variants()` zwraca to,
co przeszło bramkę.

Układ zabudowy jest wspólny dla wszystkich wariantów, zmieniają się fronty
i blat — bo tak to działa u dewelopera: rozkład kuchni jest ustalony, kupujący
wybiera wykończenie. Pole `casework_kit` przy pakiecie pozwala Standardowi
i Premium mieć inne fronty przy tych samych korpusach.

`boxes_on_outline()` ustawia kolejne ciągi wzdłuż kolejnych odcinków obrysu,
odsunięte w głąb pokoju o pół głębokości plus grubość połowy ściany. Kierunek
„do wnętrza" wyznacza znak pola sznurowadła, więc obrys zapisany zgodnie
z ruchem wskazówek zegara działa tak samo jak przeciwnie.

## Referencja przełączania

`web/warianty.template.html` to działający wzorzec do przeniesienia do
`web/index.html`. `warianty.py --demo` skleja go z danymi w jeden plik, który
otwiera się dwuklikiem.

Spacer z poziomu oczu, pasek wyboru na dole, klawisze `1…9`, głęboki link
`?wariant=premium` do wysłania kupującemu. HUD pokazuje **pomieszczenie,
w którym stoi kamera** — ten sam test punktu w wielokącie, którego używają
kolizje — jego metraż, cenę całego mieszkania i skład wykończenia tego pokoju.
Wejdź do łazienki, a lista zmienia się na płytki i znika z niej listwa.

Demo rysuje tekstury na canvasie z koloru pozycji, bo nie ma jeszcze plików
map. W produkcji w to miejsce wchodzi `TextureLoader` na ścieżkę
`material.texture` — reszta mechanizmu, ze skalą UV włącznie, zostaje bez
zmian. Sprawdzone w Chromium: przełączanie działa, konsola czysta.

**`catalog/apartment.py` — mieszkanie.** Przejście z jednego pokoju na całe
mieszkanie nie jest mnożeniem przez siedem. Zmienia się jedna rzecz w modelu:
**materiał przestaje należeć do pakietu, a zaczyna do funkcji pomieszczenia.**
Łazienka ma płytkę do sufitu i nie ma listwy, salon ma farbę i deskę — a
kupujący nadal wybiera jeden pakiet na całe mieszkanie. W katalogu robi to pole
`rooms` przy pakiecie: `"*"` to domyślne, typ pomieszczenia nadpisuje, pusta
wartość znaczy „tego tu nie ma".

Trzy rachunki, które łatwo zepsuć, i jak są liczone:

1. **Ściana działowa wchodzi dwa razy** — i tak ma być, bo malujesz obie strony.
   Powierzchnia ścian mieszkania to suma po pokojach.
2. **Podłoga sumuje się tylko przy obrysach po wewnętrznym licu ścian.** Moduł
   tego nie sprawdza, ale `Apartment.floor_area_m2` jest sumą pokoi i nie udaje
   powierzchni z aktu notarialnego.
3. **Drzwi między salonem a przedpokojem są na liście otworów obu pokoi.** Do
   wyceny liczą się raz — po wspólnym `id` otworu. Bez tego pola mieszkanie
   z czterema drzwiami wyceniłoby osiem.

Doszedł też trzeci rodzaj otworu: `passage` — przejście bez skrzydła. Przerywa
listwę jak drzwi, ale nie jest pozycją do kupienia.

## Bramka licencyjna

To jest właściwy powód, dla którego moduł wygląda tak, a nie prościej.

Każda pozycja niesie `provenance.license` i `price.status`. Do sceny oglądanej
przez kupującego mieszkanie wolno wpuścić tylko:

| licencja | znaczenie |
|---|---|
| `cc0` | domena publiczna, wolno wszystko |
| `written_consent` | producent potwierdził na piśmie |
| `purchased` | kupiona licencja royalty-free |

Nie przechodzą:

| licencja | dlaczego |
|---|---|
| `designer_zone` | pobrane ze strefy projektanta producenta — to zgoda na *wizualizację dla klienta*, nie na aplikację komercyjną |
| `example_only` | geometria syntetyczna, tylko do testów |

Analogicznie ceny: `placeholder` nie przechodzi, `listed` / `feed` / `quoted` tak.

`Quote.sendable` jest `False`, dopóki cokolwiek jest zablokowane, a `wycen.py`
kończy się kodem `1`. Kwoty i tak się liczą — blokada dotyczy wysyłki, nie
rachunku. Dzięki temu nie da się przypadkiem wystawić oferty na meble, na które
nie ma zgody.

## Dane przykładowe

`data/mieszkanie.example.json` — mieszkanie 2-pokojowe, pięć pomieszczeń,
59,57 m² sumy podłóg, cztery drzwi (nie osiem — wspólne `id`), pięć okien,
jedno przejście bez skrzydła między salonem a kuchnią.

`data/scene.example.json` — pojedynczy obrys L, 24,00 m². Zostaje, bo sceny
jednopokojowe przechodzą przez ten sam adapter.

`data/catalog.example.json` — 17 pozycji z realnymi markami i realnymi adresami
źródeł (VOX, Cersanit, Porta, Nowodvorski, BRW), ale **ceny są zerowe
i oznaczone `placeholder`**, a licencje jako `designer_zone`. Nie wymyślam cen
i nie zakładam zgód, których nie ma. Katalog służy do sprawdzenia mechanizmu —
i sprawdza go dobrze, bo oba pakiety wychodzą zablokowane, a jedyną pozycją,
która przechodzi bramkę, jest roślina z Poly Haven na CC0.

Gdy pojawi się pierwsza pisemna zgoda i cennik, zmiana dotyczy dwóch pól przy
pozycji — reszta działa bez ruszania kodu.

## Czego tu jeszcze nie ma

- konwerter `.skp`/`.3ds` → glTF (decymacja, wypalenie, KTX2, Draco)
- prawdziwe tekstury zamiast barw zastępczych
- automatyczne wykrywanie odcinków ścian pod zabudowę — dziś długości podaje się ręcznie
- moduły specjalne: zlewozmywakowy, pod piekarnik, narożny
- prawdziwe kolizje w demie: dziś ścianki działowe nie zatrzymują, żeby dało
  się przejść między pokojami (otworów drzwiowych nie ma w danych)
- eksport wyceny do PDF

"""Przedmiar liczony z geometrii sceny.

Wejsciem jest obrys pomieszczenia w metrach, wysokosc scian i lista otworow.
Wyjsciem sa ilosci, ktorymi mnozy sie ceny jednostkowe z katalogu.

Obrys to ten sam wielokat, ktorego przegladarka uzywa do kolizji, wiec wycena
i spacer licza z jednego zrodla. Jesli obrys sie zmieni, zmieni sie oboje.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Iterable, Sequence


Point = tuple[float, float]

# Klucze, pod ktorymi obrys bywa zapisany w scene.json. Adapter probuje ich
# po kolei; jesli zaden nie pasuje, blad wymienia wszystkie, zeby bylo widac
# czego szukal.
OUTLINE_KEYS = ("outline", "obrys", "footprint", "polygon", "boundary")
HEIGHT_KEYS = ("wall_height", "wallHeight", "height", "wysokosc_scian")
OPENING_KEYS = ("openings", "otwory", "holes")


class TakeoffError(ValueError):
    """Scena nie zawiera danych potrzebnych do przedmiaru."""


# Rodzaje otworow.
#   door    - otwor ze skrzydlem; przerywa listwe, liczy sie do wyceny drzwi
#   passage - otwor bez skrzydla (przejscie salon-kuchnia); przerywa listwe,
#             ale nie jest pozycja do kupienia
#   window  - nie przerywa listwy, bo ma podokiennik ponad podloga
OPENING_KINDS = ("door", "passage", "window")

# Otwory przerywajace listwe przypodlogowa.
FLOOR_LEVEL_KINDS = frozenset({"door", "passage"})


@dataclass(frozen=True)
class Opening:
    kind: str
    width_m: float
    height_m: float
    # Wspolny identyfikator otworu widzianego z dwoch pomieszczen. Drzwi miedzy
    # salonem a przedpokojem sa na liscie obu pokoi - bez tego pola weszlyby
    # do wyceny dwa razy.
    id: str = ""

    @property
    def area_m2(self) -> float:
        return self.width_m * self.height_m


@dataclass(frozen=True)
class Takeoff:
    """Ilosci wynikajace z geometrii, przed doliczeniem ubytku."""

    floor_area_m2: float
    ceiling_area_m2: float
    wall_area_gross_m2: float
    wall_area_net_m2: float
    perimeter_m: float
    skirting_m: float
    doors: int
    windows: int

    def quantity_for_surface(self, surface: str) -> float:
        if surface == "floor":
            return self.floor_area_m2
        if surface == "ceiling":
            return self.ceiling_area_m2
        if surface == "wall":
            return self.wall_area_net_m2
        if surface == "skirting":
            return self.skirting_m
        raise TakeoffError(f"nieznana powierzchnia: {surface!r}")

    def quantity_for_key(self, key: str) -> int:
        if key == "doors":
            return self.doors
        if key == "windows":
            return self.windows
        raise TakeoffError(f"nieznany klucz ilosci: {key!r}")


# --- geometria -------------------------------------------------------------


def polygon_area(points: Sequence[Point]) -> float:
    """Pole wielokata metoda sznurowadla. Zwraca wartosc dodatnia niezaleznie
    od tego, czy obrys zapisano zgodnie z ruchem wskazowek zegara, czy nie."""
    if len(points) < 3:
        raise TakeoffError(f"obrys ma {len(points)} wierzcholkow, potrzeba co najmniej 3")
    total = 0.0
    for i, (x1, y1) in enumerate(points):
        x2, y2 = points[(i + 1) % len(points)]
        total += x1 * y2 - x2 * y1
    return abs(total) / 2.0


def polygon_perimeter(points: Sequence[Point]) -> float:
    if len(points) < 3:
        raise TakeoffError(f"obrys ma {len(points)} wierzcholkow, potrzeba co najmniej 3")
    total = 0.0
    for i, (x1, y1) in enumerate(points):
        x2, y2 = points[(i + 1) % len(points)]
        total += math.hypot(x2 - x1, y2 - y1)
    return total


# --- przedmiar -------------------------------------------------------------


def compute_takeoff(
    outline: Sequence[Point],
    wall_height_m: float,
    openings: Iterable[Opening] = (),
) -> Takeoff:
    if wall_height_m <= 0:
        raise TakeoffError(f"wysokosc scian musi byc dodatnia, jest {wall_height_m}")

    openings = list(openings)
    for opening in openings:
        if opening.kind not in OPENING_KINDS:
            raise TakeoffError(
                f"otwor ma rodzaj {opening.kind!r}, znane: {OPENING_KINDS}"
            )
        if opening.width_m <= 0 or opening.height_m <= 0:
            raise TakeoffError(
                f"otwor {opening.kind} ma niedodatni wymiar "
                f"({opening.width_m} x {opening.height_m})"
            )

    floor = polygon_area(outline)
    perimeter = polygon_perimeter(outline)
    gross = perimeter * wall_height_m
    openings_area = sum(o.area_m2 for o in openings)

    if openings_area > gross:
        raise TakeoffError(
            f"otwory maja lacznie {openings_area:.2f} m2, a sciany tylko {gross:.2f} m2"
        )

    doors = [o for o in openings if o.kind == "door"]
    windows = [o for o in openings if o.kind == "window"]
    przy_podlodze = [o for o in openings if o.kind in FLOOR_LEVEL_KINDS]

    # Listwa przypodlogowa biegnie po obwodzie, ale urywa sie w swietle drzwi
    # i przejsc. Okna jej nie przerywaja, bo maja podokiennik ponad podloga.
    szerokosc_przerw = sum(o.width_m for o in przy_podlodze)
    skirting = perimeter - szerokosc_przerw
    if skirting < 0:
        raise TakeoffError(
            f"otwory przy podlodze sa lacznie szersze ({szerokosc_przerw:.2f} m) "
            f"niz obwod pomieszczenia ({perimeter:.2f} m)"
        )

    return Takeoff(
        floor_area_m2=floor,
        ceiling_area_m2=floor,
        wall_area_gross_m2=gross,
        wall_area_net_m2=gross - openings_area,
        perimeter_m=perimeter,
        skirting_m=skirting,
        doors=len(doors),
        windows=len(windows),
    )


# --- adapter na scene.json -------------------------------------------------


def _first_key(raw: dict[str, Any], keys: Sequence[str], what: str) -> Any:
    for key in keys:
        if key in raw:
            return raw[key]
    raise TakeoffError(
        f"nie znalazlem {what} w scenie; szukalem pod kluczami: {', '.join(keys)}"
    )


def _as_points(raw: Any) -> list[Point]:
    points: list[Point] = []
    for entry in raw:
        if isinstance(entry, dict):
            if "x" not in entry or "y" not in entry:
                raise TakeoffError(f"wierzcholek obrysu bez x/y: {entry!r}")
            points.append((float(entry["x"]), float(entry["y"])))
        elif isinstance(entry, (list, tuple)) and len(entry) >= 2:
            points.append((float(entry[0]), float(entry[1])))
        else:
            raise TakeoffError(f"nie umiem odczytac wierzcholka obrysu: {entry!r}")
    return points


def _as_openings(raw: Any) -> list[Opening]:
    openings: list[Opening] = []
    for entry in raw or ():
        if not isinstance(entry, dict):
            raise TakeoffError(f"otwor nie jest obiektem: {entry!r}")
        kind = str(entry.get("kind") or entry.get("type") or entry.get("rodzaj") or "")
        if kind in ("drzwi", "door"):
            kind = "door"
        elif kind in ("okno", "window"):
            kind = "window"
        elif kind in ("przejscie", "przejscie_bez_drzwi", "passage"):
            kind = "passage"
        else:
            raise TakeoffError(
                f"otwor ma nieznany rodzaj {kind!r}; oczekiwano door/passage/window"
            )
        width = entry.get("width", entry.get("w", entry.get("szerokosc")))
        height = entry.get("height", entry.get("h", entry.get("wysokosc")))
        if width is None or height is None:
            raise TakeoffError(f"otwor bez szerokosci lub wysokosci: {entry!r}")
        openings.append(
            Opening(
                kind=kind,
                width_m=float(width),
                height_m=float(height),
                id=str(entry.get("id", "")),
            )
        )
    return openings


def takeoff_from_scene(scene: dict[str, Any]) -> Takeoff:
    """Przedmiar wprost ze slownika wczytanego ze scene.json.

    UWAGA: nazwy kluczy sa zgadywane spomiedzy kilku wariantow (patrz stale
    OUTLINE_KEYS / HEIGHT_KEYS / OPENING_KEYS). Gdy scene.json ustabilizuje
    kontrakt, ta funkcja powinna zejsc do jednego zestawu nazw.

    Jednostki: obrys i wysokosc w METRACH. Jesli scena trzyma centymetry,
    przelicz przed wywolaniem - modul nie zgaduje jednostek.
    """
    room = scene.get("room", scene)
    outline = _as_points(_first_key(room, OUTLINE_KEYS, "obrysu pomieszczenia"))
    height = float(_first_key(room, HEIGHT_KEYS, "wysokosci scian"))
    openings_raw: Any = ()
    for key in OPENING_KEYS:
        if key in room:
            openings_raw = room[key]
            break
    return compute_takeoff(outline, height, _as_openings(openings_raw))

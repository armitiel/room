"""Warianty wykonczenia: kontrakt miedzy generatorem a przegladarka.

Wariant to nie druga scena. To ta sama geometria z podmieniona zawartoscia
gniazd materialowych. Dzieki temu przelaczenie w spacerze jest natychmiastowe -
nie ma ponownego wczytywania glTF, nie ma utraty pozycji kamery, nie ma
bialego blysku.

Gniazda rozwiazuja sie PER POMIESZCZENIE, bo material nalezy do funkcji pokoju,
a nie do pakietu: lazienka ma plytke do sufitu, salon farbe. Kupujacy wybiera
jeden pakiet na cale mieszkanie - decyduje, KTORA plytka i ktora farba, a nie
gdzie ktora idzie.

Plik variants.json niesie tez cene policzona TU, po stronie generatora.
Przegladarka nie liczy pieniedzy - dostaje gotowa kwote razem z informacja,
czy wolno ja pokazac klientowi.
"""

from __future__ import annotations

import datetime
from typing import Iterable

from .apartment import Apartment, ApartmentQuote, quote_apartment
from .casework import (
    Bom,
    CaseworkKit,
    Run,
    bom_for_runs,
    boxes_on_outline,
    quote_casework,
)
from .model import Catalog, Item, Package

VARIANTS_SCHEMA_VERSION = 2

# Gniazda rozwiazywane osobno w kazdym pomieszczeniu.
ROOM_SLOTS = ("floor", "wall", "ceiling", "skirting")

# Gniazda zabudowy - wspolne dla mieszkania, bo uklad szafek jest jeden.
CASEWORK_SLOTS = ("casework_front", "casework_worktop")

MATERIAL_SLOTS = ROOM_SLOTS + CASEWORK_SLOTS

CASEWORK_SLOT_ROLES = {
    "casework_front": "board_front",
    "casework_worktop": "worktop",
}

FALLBACK_COLOR = "#cccccc"


def _material_payload(item: Item) -> dict:
    """Opis materialu w postaci, ktora przegladarka umie zalozyc na siatke.

    module_mm jest tu najwazniejsze: bez niego plytka 30 x 90 renderuje sie
    jak tapeta, bo silnik nie wie, ile razy powtorzyc teksture na scianie.
    """
    return {
        "item_id": item.id,
        "name": item.name,
        "brand": item.brand,
        "color": item.color or FALLBACK_COLOR,
        "texture": item.texture,
        "module_mm": list(item.module_mm),
        "unit_price_net": item.price.net,
        "price_status": item.price.status,
        "license": item.provenance.license,
        "source_url": item.provenance.source_url,
    }


def _object_payload(item: Item, count: int) -> dict:
    return {
        "item_id": item.id,
        "name": item.name,
        "brand": item.brand,
        "count": count,
        "slot": item.slot,
        "anchor": item.anchor,
        "color": item.color or FALLBACK_COLOR,
        "model": item.model,
        "dimensions_mm": dict(item.dimensions_mm),
        "license": item.provenance.license,
    }


def _price_payload(net: float, vat: float, gross: float, currency: str) -> dict:
    return {
        "net": round(net, 2),
        "vat": round(vat, 2),
        "gross": round(gross, 2),
        "currency": currency,
    }


def build_variant(
    catalog: Catalog,
    package: Package,
    apartment: Apartment,
    kit: CaseworkKit | None = None,
    casework_bom: Bom | None = None,
) -> dict:
    """Jeden wariant: materialy per pomieszczenie, obiekty, cena, stan bramki."""
    wycena: ApartmentQuote = quote_apartment(catalog, package, apartment)

    pokoje: dict[str, dict] = {}
    for room in apartment.rooms:
        materialy: dict[str, dict] = {}
        for surface, item_id in package.surfaces_for(room.type).items():
            if not item_id:
                continue  # jawny brak, np. listwa w lazience
            materialy[surface] = _material_payload(catalog.items[item_id])
        quote = wycena.per_room[room.id]
        pokoje[room.id] = {
            "name": room.name,
            "type": room.type,
            "materials": materialy,
            "price": _price_payload(quote.net, quote.vat, quote.gross, catalog.currency),
        }

    obiekty: list[dict] = []
    for item_id, quantity_key in package.from_takeoff.items():
        count = apartment.quantity_for_key(quantity_key)
        if count:
            obiekty.append(_object_payload(catalog.items[item_id], count))
    for item_id, count in package.objects.items():
        if count:
            obiekty.append(_object_payload(catalog.items[item_id], count))

    zabudowa: dict[str, dict] = {}
    net, vat, gross = wycena.net, wycena.vat, wycena.gross
    warnings = list(wycena.warnings)

    if kit is not None and casework_bom is not None:
        wycena_zabudowy = quote_casework(catalog, kit, casework_bom, label=kit.name)
        net += wycena_zabudowy.net
        vat += wycena_zabudowy.vat
        gross += wycena_zabudowy.gross
        warnings += [w for w in wycena_zabudowy.warnings if w not in warnings]
        for slot, role in CASEWORK_SLOT_ROLES.items():
            item_id = kit.roles.get(role)
            if item_id:
                zabudowa[slot] = _material_payload(catalog.items[item_id])

    return {
        "id": package.id,
        "name": package.name,
        "draft": bool(warnings),
        "blockers": warnings,
        "price": _price_payload(net, vat, gross, catalog.currency),
        "rooms": pokoje,
        "casework_materials": zabudowa,
        "objects": sorted(obiekty, key=lambda o: o["item_id"]),
    }


def build_variants(
    catalog: Catalog,
    apartment: Apartment,
    kits: dict[str, CaseworkKit] | None = None,
    kit_id: str = "",
    casework_runs: Iterable[tuple[Run, str]] = (),
    generated: str = "",
) -> dict:
    """Caly plik variants.json.

    casework_runs to pary (ciag, id_pomieszczenia); ciag ustawia sie wzdluz
    obrysu wskazanego pokoju. Uklad zabudowy jest wspolny dla wszystkich
    wariantow, zmieniaja sie fronty i blat.
    """
    kits = kits or {}

    def resolve_kit(package: Package) -> CaseworkKit | None:
        wanted = package.casework_kit or kit_id
        if not wanted:
            return None
        if wanted not in kits:
            raise KeyError(
                f"pakiet {package.id!r} chce zestawu zabudowy {wanted!r}, "
                f"a znam: {', '.join(sorted(kits)) or 'zaden'}"
            )
        return kits[wanted]

    pary = list(casework_runs)
    bom = bom_for_runs([run for run, _ in pary]) if pary else None

    boxes: list[dict] = []
    for run, room_id in pary:
        obrys = apartment.by_id(room_id).outline_m if room_id else ()
        for box in boxes_on_outline([run], obrys):
            box["room"] = room_id
            boxes.append(box)

    variants = [
        build_variant(catalog, package, apartment, resolve_kit(package), bom)
        for package in sorted(catalog.packages.values(), key=lambda p: p.id)
    ]

    return {
        "schema_version": VARIANTS_SCHEMA_VERSION,
        "currency": catalog.currency,
        "generated": generated or datetime.date.today().isoformat(),
        "room_slots": list(ROOM_SLOTS),
        "casework_slots": list(CASEWORK_SLOTS),
        "apartment": {
            "floor_area_m2": round(apartment.floor_area_m2, 3),
            "wall_area_net_m2": round(apartment.wall_area_net_m2, 3),
            "skirting_m": round(apartment.skirting_m, 3),
            "doors": apartment.doors,
            "windows": apartment.windows,
            "rooms": [
                {
                    "id": room.id,
                    "name": room.name,
                    "type": room.type,
                    "outline_m": [[x, y] for x, y in room.outline_m],
                    "wall_height_m": room.wall_height_m,
                    "floor_area_m2": round(room.takeoff.floor_area_m2, 3),
                }
                for room in apartment.rooms
            ],
        },
        "casework": boxes,
        "variants": variants,
    }


def client_safe_variants(variants_doc: dict) -> list[dict]:
    """Warianty, ktore wolno pokazac kupujacemu mieszkanie."""
    return [v for v in variants_doc["variants"] if not v["draft"]]

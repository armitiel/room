"""Parametryczna zabudowa: szafy i kuchnie.

Szafa i kuchnia to bryly pudelkowe, wiec nie trzeba ich skadkolwiek sciagac -
da sie je policzyc. To zdejmuje z katalogu najwieksza pozycje wyceny i robi
z niej wlasna geometrie, bez licencji i bez zgod producenta.

Rachunek idzie w milimetrach, a dopiero przedmiar wychodzi w metrach
i sztukach, zeby nie gubic sie na zaokragleniach.

Kolejnosc: odcinek sciany -> podzial na moduly -> rozkroj plyty -> wycena.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Iterable, Sequence

from .model import CASEWORK_ROLE_UNITS, Catalog, CatalogError, Item
from .pricing import Quote, QuoteLine

MM2_PER_M2 = 1_000_000.0
MM_PER_M = 1000.0

# Szereg szerokosci korpusow spotykany u polskich producentow plyty.
STANDARD_WIDTHS_MM: tuple[int, ...] = (300, 400, 450, 500, 600, 800, 900)

# Ponizej tej szerokosci nie robi sie modulu - reszta idzie na blende.
MIN_MODULE_MM = 300

# Wymiary domyslne wedlug rodzaju zabudowy.
KIND_DEFAULTS: dict[str, dict[str, int]] = {
    "base": {"height_mm": 720, "depth_mm": 560},   # szafka dolna, pod blatem
    "wall": {"height_mm": 720, "depth_mm": 320},   # szafka gorna
    "tall": {"height_mm": 2100, "depth_mm": 560},  # slupek / szafa
}

# Grubosci materialow.
BOARD_MM = 18      # plyta korpusowa i fronty
BACK_MM = 3        # plecy HDF

# Szczelina wokol frontu (fuga).
FRONT_GAP_MM = 3

# Odsuniecie polki od frontu, zeby nie kolidowala z zawiasem.
SHELF_SETBACK_MM = 20

# Modul szerszy niz to dostaje dwa skrzydla zamiast jednego.
DOUBLE_DOOR_ABOVE_MM = 700

# Progi liczby zawiasow wedlug wysokosci frontu.
HINGE_STEPS_MM: tuple[tuple[int, int], ...] = ((900, 2), (1600, 3), (2000, 4), (2400, 5))

# Role materialowe, ktorymi zabudowa rozlicza sie w katalogu.
# Slownik zywy w model.py, zeby walidator katalogu i generator mowily o tym samym.
ROLE_UNITS = CASEWORK_ROLE_UNITS

ROLE_LABELS: dict[str, str] = {
    "board_carcass": "plyta korpusowa",
    "board_front": "fronty",
    "board_back": "plecy HDF",
    "edge_banding": "obrzeze",
    "hinge": "zawiasy",
    "drawer_slide": "prowadnice (komplety)",
    "handle": "uchwyty",
    "worktop": "blat",
    "plinth": "cokol",
}


class CaseworkError(ValueError):
    """Nie da sie zaplanowac zabudowy dla podanych danych."""


# --- modul -----------------------------------------------------------------


@dataclass(frozen=True)
class Module:
    """Pojedyncza szafka."""

    kind: str          # base | wall | tall
    width_mm: int
    height_mm: int
    depth_mm: int
    doors: int = 1
    drawers: int = 0
    shelves: int = 1

    def validate(self) -> None:
        if self.kind not in KIND_DEFAULTS:
            raise CaseworkError(
                f"nieznany rodzaj modulu {self.kind!r}, znane: {tuple(KIND_DEFAULTS)}"
            )
        for label, value in (
            ("szerokosc", self.width_mm),
            ("wysokosc", self.height_mm),
            ("glebokosc", self.depth_mm),
        ):
            if value <= 0:
                raise CaseworkError(f"{label} modulu musi byc dodatnia, jest {value}")
        if self.doors < 0 or self.drawers < 0 or self.shelves < 0:
            raise CaseworkError("liczba frontow, szuflad i polek nie moze byc ujemna")
        if self.width_mm < MIN_MODULE_MM:
            raise CaseworkError(
                f"modul {self.width_mm} mm jest wezszy niz minimum {MIN_MODULE_MM} mm"
            )

    @property
    def interior_width_mm(self) -> int:
        """Swiatlo miedzy bokami korpusu."""
        return self.width_mm - 2 * BOARD_MM

    @property
    def front_height_mm(self) -> float:
        """Wysokosc pojedynczego frontu drzwiowego."""
        if self.drawers and not self.doors:
            return 0.0
        drawer_zone = self.drawers * self._drawer_front_height_mm()
        return self.height_mm - FRONT_GAP_MM - drawer_zone

    def _drawer_front_height_mm(self) -> float:
        """Szuflady dziela dolna czesc modulu na rowne fronty."""
        if not self.drawers:
            return 0.0
        if self.doors:
            # szuflady zajmuja trzecia czesc wysokosci, reszta pod drzwi
            zone = self.height_mm / 3.0
        else:
            zone = self.height_mm - FRONT_GAP_MM
        return zone / self.drawers

    def front_width_mm(self) -> float:
        if self.doors <= 0:
            return self.width_mm - FRONT_GAP_MM
        return (self.width_mm - FRONT_GAP_MM * self.doors) / self.doors

    def hinges(self) -> int:
        if self.doors <= 0:
            return 0
        height = self.front_height_mm
        per_door = HINGE_STEPS_MM[-1][1]
        for limit, count in HINGE_STEPS_MM:
            if height <= limit:
                per_door = count
                break
        return per_door * self.doors

    def handles(self) -> int:
        return self.doors + self.drawers


def default_module(kind: str, width_mm: int, **nadpisz) -> Module:
    """Modul o wymiarach domyslnych dla rodzaju, z dwoma skrzydlami gdy szeroki."""
    if kind not in KIND_DEFAULTS:
        raise CaseworkError(
            f"nieznany rodzaj zabudowy {kind!r}, znane: {tuple(KIND_DEFAULTS)}"
        )
    base = dict(KIND_DEFAULTS[kind])
    doors = 2 if width_mm > DOUBLE_DOOR_ABOVE_MM else 1
    params = {
        "kind": kind,
        "width_mm": width_mm,
        "height_mm": base["height_mm"],
        "depth_mm": base["depth_mm"],
        "doors": doors,
        "drawers": 0,
        "shelves": 1,
    }
    params.update(nadpisz)
    module = Module(**params)  # type: ignore[arg-type]
    module.validate()
    return module


# --- podzial odcinka -------------------------------------------------------


@dataclass(frozen=True)
class Run:
    """Ciag szafek na jednym odcinku sciany."""

    name: str
    kind: str
    length_mm: int
    modules: tuple[Module, ...]
    filler_mm: int  # blenda / szczelina domykajaca ciag

    @property
    def modules_width_mm(self) -> int:
        return sum(m.width_mm for m in self.modules)


def _partition(length_mm: int, widths: Sequence[int]) -> list[int]:
    """Podziel odcinek na moduly, minimalizujac najpierw resztke, potem liczbe szafek.

    Programowanie dynamiczne po milimetrach jest tu tanie, bo odcinki scian
    to najwyzej kilka metrow, a szerokosci sa wielokrotnosciami 50 mm.
    """
    if length_mm < MIN_MODULE_MM:
        return []

    usable = [w for w in sorted(set(widths)) if w >= MIN_MODULE_MM]
    if not usable:
        raise CaseworkError("brak szerokosci modulow spelniajacych minimum")

    step = math.gcd(*usable) if len(usable) > 1 else usable[0]
    step = math.gcd(step, length_mm) or 1

    def spread(layout: tuple[int, ...]) -> int:
        """Rozrzut szerokosci. Przy tej samej liczbie szafek wybieramy ciag
        bardziej rowny - 900+900+600+600 zamiast 900+900+900+300."""
        return max(layout) - min(layout) if layout else 0

    cells = length_mm // step
    # best[i] = (liczba modulow, rozklad) dla dokladnie i * step mm
    best: list[tuple[int, tuple[int, ...]] | None] = [None] * (cells + 1)
    best[0] = (0, ())
    for i in range(1, cells + 1):
        for w in usable:
            if w % step:
                continue
            prev = i - w // step
            if prev < 0 or best[prev] is None:
                continue
            count, layout = best[prev]  # type: ignore[misc]
            candidate = (count + 1, layout + (w,))
            current = best[i]
            if current is None:
                best[i] = candidate
                continue
            # Rozstrzygniecie heurystyczne, nie dowod optymalnosci: liczba
            # szafek jest twarda, rownosc szerokosci tylko preferowana.
            key_new = (candidate[0], spread(candidate[1]))
            key_old = (current[0], spread(current[1]))
            if key_new < key_old:
                best[i] = candidate

    for i in range(cells, -1, -1):
        if best[i] is not None:
            return list(best[i][1])  # type: ignore[index]
    return []


def plan_run(
    name: str,
    kind: str,
    length_mm: int,
    widths: Sequence[int] = STANDARD_WIDTHS_MM,
    module_overrides: dict[int, dict] | None = None,
) -> Run:
    """Rozloz zabudowe na odcinku sciany o dlugosci length_mm.

    module_overrides pozwala zmienic pojedynczy modul po jego pozycji w ciagu,
    np. {0: {"drawers": 3, "doors": 0}} robi z pierwszej szafki komode.
    """
    if length_mm <= 0:
        raise CaseworkError(f"dlugosc odcinka musi byc dodatnia, jest {length_mm}")

    layout = _partition(length_mm, widths)
    overrides = module_overrides or {}
    modules = [
        default_module(kind, width, **overrides.get(index, {}))
        for index, width in enumerate(layout)
    ]
    filler = length_mm - sum(layout)
    return Run(
        name=name,
        kind=kind,
        length_mm=length_mm,
        modules=tuple(modules),
        filler_mm=filler,
    )


# --- rozkroj ---------------------------------------------------------------


@dataclass
class Bom:
    """Przedmiar zabudowy w jednostkach handlowych."""

    board_carcass_m2: float = 0.0
    board_front_m2: float = 0.0
    board_back_m2: float = 0.0
    edge_banding_m: float = 0.0
    hinge: int = 0
    drawer_slide: int = 0
    handle: int = 0
    worktop_m: float = 0.0
    plinth_m: float = 0.0

    def quantity_for_role(self, role: str) -> float:
        mapping = {
            "board_carcass": self.board_carcass_m2,
            "board_front": self.board_front_m2,
            "board_back": self.board_back_m2,
            "edge_banding": self.edge_banding_m,
            "hinge": float(self.hinge),
            "drawer_slide": float(self.drawer_slide),
            "handle": float(self.handle),
            "worktop": self.worktop_m,
            "plinth": self.plinth_m,
        }
        if role not in mapping:
            raise CaseworkError(f"nieznana rola materialowa: {role!r}")
        return mapping[role]

    def merge(self, other: "Bom") -> "Bom":
        return Bom(
            board_carcass_m2=self.board_carcass_m2 + other.board_carcass_m2,
            board_front_m2=self.board_front_m2 + other.board_front_m2,
            board_back_m2=self.board_back_m2 + other.board_back_m2,
            edge_banding_m=self.edge_banding_m + other.edge_banding_m,
            hinge=self.hinge + other.hinge,
            drawer_slide=self.drawer_slide + other.drawer_slide,
            handle=self.handle + other.handle,
            worktop_m=self.worktop_m + other.worktop_m,
            plinth_m=self.plinth_m + other.plinth_m,
        )


def bom_for_module(module: Module) -> Bom:
    """Rozkroj pojedynczej szafki.

    Korpus: dwa boki na pelna wysokosc, wieniec dolny i gorny miedzy bokami,
    polki w swietle korpusu cofniete o SHELF_SETBACK_MM od frontu.
    Plecy z HDF na obrys modulu.
    """
    module.validate()

    sides = 2 * (module.height_mm * module.depth_mm)
    rails = 2 * (module.interior_width_mm * module.depth_mm)
    shelves = module.shelves * (
        module.interior_width_mm * (module.depth_mm - SHELF_SETBACK_MM)
    )
    carcass_mm2 = sides + rails + shelves

    back_mm2 = module.width_mm * module.height_mm

    front_w = module.front_width_mm()
    door_h = module.front_height_mm if module.doors else 0.0
    drawer_h = module._drawer_front_height_mm()

    fronts_mm2 = module.doors * (front_w * door_h)
    fronts_mm2 += module.drawers * ((module.width_mm - FRONT_GAP_MM) * drawer_h)

    # Obrzeze: fronty po calym obwodzie, polki tylko po krawedzi widocznej.
    edge_mm = module.doors * 2 * (front_w + door_h)
    edge_mm += module.drawers * 2 * ((module.width_mm - FRONT_GAP_MM) + drawer_h)
    edge_mm += module.shelves * module.interior_width_mm

    return Bom(
        board_carcass_m2=carcass_mm2 / MM2_PER_M2,
        board_front_m2=fronts_mm2 / MM2_PER_M2,
        board_back_m2=back_mm2 / MM2_PER_M2,
        edge_banding_m=edge_mm / MM_PER_M,
        hinge=module.hinges(),
        drawer_slide=module.drawers,
        handle=module.handles(),
        worktop_m=(module.width_mm / MM_PER_M) if module.kind == "base" else 0.0,
        plinth_m=(module.width_mm / MM_PER_M) if module.kind == "base" else 0.0,
    )


def bom_for_run(run: Run) -> Bom:
    """Rozkroj calego ciagu. Blenda dolicza sie do frontow i blatu."""
    total = Bom()
    for module in run.modules:
        total = total.merge(bom_for_module(module))

    if run.filler_mm > 0:
        height = run.modules[0].height_mm if run.modules else KIND_DEFAULTS[run.kind]["height_mm"]
        total.board_front_m2 += (run.filler_mm * height) / MM2_PER_M2
        total.edge_banding_m += 2 * (run.filler_mm + height) / MM_PER_M
        if run.kind == "base":
            total.worktop_m += run.filler_mm / MM_PER_M
            total.plinth_m += run.filler_mm / MM_PER_M

    return total


def bom_for_runs(runs: Iterable[Run]) -> Bom:
    total = Bom()
    for run in runs:
        total = total.merge(bom_for_run(run))
    return total


# --- wycena ----------------------------------------------------------------


@dataclass(frozen=True)
class CaseworkKit:
    """Zestaw materialowy: rola -> pozycja katalogu."""

    id: str
    name: str
    roles: dict[str, str] = field(default_factory=dict)

    def validate(self, items: dict[str, Item]) -> list[str]:
        where = f"casework_kit[{self.id}]"
        errs: list[str] = []
        if not self.name:
            errs.append(f"{where}: brak name")
        for role, item_id in self.roles.items():
            if role not in ROLE_UNITS:
                errs.append(f"{where}: nieznana rola {role!r}, znane: {tuple(ROLE_UNITS)}")
                continue
            item = items.get(item_id)
            if item is None:
                errs.append(f"{where}: rola {role} wskazuje na nieznane id {item_id!r}")
                continue
            if item.kind != "component":
                errs.append(
                    f"{where}: rola {role} wskazuje na {item.kind}, a wymaga component"
                )
            elif item.role != role:
                errs.append(
                    f"{where}: pozycja {item_id} ma role {item.role!r}, "
                    f"a zestaw uzywa jej jako {role!r}"
                )
            if item.unit != ROLE_UNITS[role]:
                errs.append(
                    f"{where}: rola {role} wymaga jednostki {ROLE_UNITS[role]}, "
                    f"a {item_id} jest w {item.unit}"
                )
        return errs


def kit_from_dict(raw: dict) -> CaseworkKit:
    return CaseworkKit(
        id=str(raw.get("id", "")),
        name=str(raw.get("name", "")),
        roles={str(k): str(v) for k, v in raw.get("roles", {}).items()},
    )


def kits_from_catalog_dict(raw: dict) -> dict[str, CaseworkKit]:
    kits: dict[str, CaseworkKit] = {}
    for entry in raw.get("casework_kits", []):
        kit = kit_from_dict(entry)
        if kit.id in kits:
            raise CatalogError(f"zduplikowane id zestawu zabudowy: {kit.id}")
        kits[kit.id] = kit
    return kits


def quote_casework(
    catalog: Catalog,
    kit: CaseworkKit,
    bom: Bom,
    label: str = "Zabudowa",
) -> Quote:
    """Wycen zabudowe tym samym mechanizmem co reszte - z ta sama bramka."""
    errs = kit.validate(catalog.items)
    if errs:
        raise CatalogError("zestaw zabudowy nie spelnia kontraktu:\n  " + "\n  ".join(errs))

    lines: list[QuoteLine] = []
    warnings: list[str] = []

    for role in ROLE_UNITS:
        item_id = kit.roles.get(role)
        if item_id is None:
            quantity = bom.quantity_for_role(role)
            if quantity > 0:
                warnings.append(
                    f"{ROLE_LABELS[role]}: przedmiar wynosi "
                    f"{quantity:.2f} {ROLE_UNITS[role]}, ale zestaw nie ma tej pozycji"
                )
            continue

        item = catalog.items[item_id]
        quantity = bom.quantity_for_role(role)
        if quantity <= 0:
            continue

        billed = quantity * (1.0 + item.waste_factor)
        lines.append(
            QuoteLine(
                item_id=item.id,
                name=f"{item.name} ({ROLE_LABELS[role]})",
                brand=item.brand,
                unit=item.unit,
                quantity_raw=quantity,
                waste_factor=item.waste_factor,
                quantity_billed=billed,
                unit_price_net=item.price.net,
                vat_rate=item.price.vat_rate,
            )
        )
        for blocker in item.blockers():
            warnings.append(f"{item.brand} {item.name}: {blocker}")

    return Quote(
        package_id=kit.id,
        package_name=label,
        currency=catalog.currency,
        lines=tuple(lines),
        warnings=tuple(dict.fromkeys(warnings)),
    )


def load_kits(path) -> dict[str, CaseworkKit]:
    """Wczytaj zestawy zabudowy z tego samego pliku, co katalog."""
    import json

    with open(path, "r", encoding="utf-8") as handle:
        return kits_from_catalog_dict(json.load(handle))


def describe_run(run: Run) -> str:
    """Czytelny opis ciagu do wydruku w konsoli."""
    widths: dict[int, int] = {}
    for module in run.modules:
        widths[module.width_mm] = widths.get(module.width_mm, 0) + 1
    parts = [f"{count} x {width}" for width, count in sorted(widths.items())]
    line = f"{run.name}: {run.length_mm} mm = " + " + ".join(parts) if parts else (
        f"{run.name}: {run.length_mm} mm - za krotki na modul"
    )
    if run.filler_mm:
        line += f" + blenda {run.filler_mm} mm"
    return line


# --- bryly do sceny --------------------------------------------------------

# Poziom, na ktorym zaczyna sie korpus, liczony od podlogi.
KIND_BASE_Z_MM: dict[str, int] = {
    "base": 100,   # na cokole
    "wall": 1450,  # nad blatem
    "tall": 100,
}

WORKTOP_MM = 38


def boxes_for_run(
    run: Run,
    origin_mm: tuple[float, float] = (0.0, 0.0),
    direction_deg: float = 0.0,
) -> list[dict]:
    """Rozloz moduly ciagu na bryly gotowe do wstawienia do sceny.

    Zwraca liste slownikow w milimetrach, w ukladzie sceny: srodek podstawy
    modulu, wymiary i obrot wokol osi pionowej. Zabudowa dzieki temu pojawia
    sie w spacerze, a nie tylko w wycenie.
    """
    angle = math.radians(direction_deg)
    ux, uy = math.cos(angle), math.sin(angle)
    boxes: list[dict] = []
    offset = 0.0

    for index, module in enumerate(run.modules):
        centre = offset + module.width_mm / 2.0
        z0 = KIND_BASE_Z_MM[module.kind]
        boxes.append(
            {
                "id": f"{run.name}.{index:02d}",
                "kind": module.kind,
                "x_mm": origin_mm[0] + ux * centre,
                "y_mm": origin_mm[1] + uy * centre,
                "z_mm": z0,
                "width_mm": module.width_mm,
                "depth_mm": module.depth_mm,
                "height_mm": module.height_mm,
                "rotation_deg": direction_deg,
            }
        )
        offset += module.width_mm

    if run.kind == "base" and run.modules:
        depth = run.modules[0].depth_mm
        z0 = KIND_BASE_Z_MM["base"] + run.modules[0].height_mm
        boxes.append(
            {
                "id": f"{run.name}.blat",
                "kind": "worktop",
                "x_mm": origin_mm[0] + ux * (run.length_mm / 2.0),
                "y_mm": origin_mm[1] + uy * (run.length_mm / 2.0),
                "z_mm": z0,
                "width_mm": run.length_mm,
                "depth_mm": depth,
                "height_mm": WORKTOP_MM,
                "rotation_deg": direction_deg,
            }
        )

    return boxes


def boxes_on_outline(
    runs: Sequence[Run],
    outline_m: Sequence[Sequence[float]],
    wall_offset_mm: float = 60.0,
) -> list[dict]:
    """Ustaw kolejne ciagi wzdluz kolejnych odcinkow obrysu pomieszczenia.

    Bez tego zabudowa lezy w poczatku ukladu i przecina sciany. To uproszczona
    wersja doboru miejsca: pierwszy ciag idzie po pierwszym odcinku, drugi po
    drugim i tak dalej. Docelowo odcinki powinny byc wskazywane w projekcie
    wnetrza, a nie zgadywane z kolejnosci.

    Kierunek "do wnetrza" wyznacza znak pola sznurowadla, wiec obrys zapisany
    zgodnie z ruchem wskazowek zegara dziala tak samo jak przeciwnie.
    """
    if not outline_m:
        boxes: list[dict] = []
        for run in runs:
            boxes += boxes_for_run(run)
        return boxes

    points = [(float(x), float(y)) for x, y in outline_m]
    n = len(points)
    signed = 0.0
    for i, (x1, y1) in enumerate(points):
        x2, y2 = points[(i + 1) % n]
        signed += x1 * y2 - x2 * y1
    ccw = signed > 0

    boxes = []
    for index, run in enumerate(runs):
        x1, y1 = points[index % n]
        x2, y2 = points[(index + 1) % n]
        dx, dy = x2 - x1, y2 - y1
        length = math.hypot(dx, dy)
        if length < 1e-6:
            boxes += boxes_for_run(run)
            continue
        ux, uy = dx / length, dy / length
        nx, ny = (-uy, ux) if ccw else (uy, -ux)

        depth = run.modules[0].depth_mm if run.modules else KIND_DEFAULTS[run.kind]["depth_mm"]
        odsuniecie = depth / 2.0 + wall_offset_mm
        origin = (x1 * MM_PER_M + nx * odsuniecie, y1 * MM_PER_M + ny * odsuniecie)
        boxes += boxes_for_run(run, origin, math.degrees(math.atan2(dy, dx)))

    return boxes

"""Mieszkanie: kilka pomieszczen, jeden pakiet, jedna wycena.

Przejscie z jednego pokoju na mieszkanie nie jest mnozeniem przez siedem.
Zmienia sie jedna rzecz w modelu: material przestaje nalezec do pakietu,
a zaczyna do FUNKCJI pomieszczenia. Lazienka ma plytke na scianie do sufitu,
salon farbe - a kupujacy nadal wybiera jeden pakiet na cale mieszkanie.

Trzy rachunki, ktore latwo zepsuc, i sposob, w jaki sa tu liczone:

1. Sciana miedzy dwoma pokojami wchodzi do przedmiaru DWA razy - i tak ma byc,
   bo malujesz obie strony. Suma powierzchni scian to suma po pokojach.

2. Podloga sumuje sie tylko wtedy, gdy obrysy poprowadzono po wewnetrznym licu
   scian. Modul tego nie sprawdza, ale `Apartment.floor_area_m2` jest suma
   pokoi i nie udaje powierzchni z aktu notarialnego.

3. Drzwi miedzy salonem a przedpokojem sa na liscie otworow obu pokoi.
   Do wyceny licza sie RAZ - po wspolnym `id` otworu.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable, Sequence

from .model import Catalog, Package
from .pricing import Quote, QuoteLine, _round_money
from .takeoff import (
    HEIGHT_KEYS,
    OPENING_KEYS,
    OUTLINE_KEYS,
    Opening,
    Takeoff,
    TakeoffError,
    _as_openings,
    _as_points,
    _first_key,
    compute_takeoff,
)

# Typ pomieszczenia uzywany, gdy scena go nie podaje. Pakiet ma dla niego
# wpis domyslny pod kluczem "*".
DEFAULT_ROOM_TYPE = "*"

ROOM_KEYS = ("rooms", "pomieszczenia", "pokoje")


@dataclass(frozen=True)
class Room:
    id: str
    name: str
    type: str
    outline_m: tuple[tuple[float, float], ...]
    wall_height_m: float
    openings: tuple[Opening, ...]
    takeoff: Takeoff


@dataclass(frozen=True)
class Apartment:
    """Zbior pomieszczen liczony razem, ale wyceniany po kolei."""

    rooms: tuple[Room, ...] = ()

    def __post_init__(self) -> None:
        widziane: set[str] = set()
        for room in self.rooms:
            if room.id in widziane:
                raise TakeoffError(f"zduplikowany identyfikator pomieszczenia: {room.id}")
            widziane.add(room.id)

    def by_id(self, room_id: str) -> Room:
        for room in self.rooms:
            if room.id == room_id:
                return room
        raise TakeoffError(f"nie ma pomieszczenia {room_id!r}")

    @property
    def floor_area_m2(self) -> float:
        return sum(r.takeoff.floor_area_m2 for r in self.rooms)

    @property
    def wall_area_net_m2(self) -> float:
        """Suma po pokojach - sciana dzialowa liczona z obu stron."""
        return sum(r.takeoff.wall_area_net_m2 for r in self.rooms)

    @property
    def skirting_m(self) -> float:
        return sum(r.takeoff.skirting_m for r in self.rooms)

    def _unique_openings(self, kind: str) -> int:
        """Otwory o wspolnym id licza sie raz, bezimienne kazdy osobno."""
        widziane: set[str] = set()
        licznik = 0
        for room in self.rooms:
            for opening in room.openings:
                if opening.kind != kind:
                    continue
                if not opening.id:
                    licznik += 1
                elif opening.id not in widziane:
                    widziane.add(opening.id)
                    licznik += 1
        return licznik

    @property
    def doors(self) -> int:
        return self._unique_openings("door")

    @property
    def windows(self) -> int:
        return self._unique_openings("window")

    def quantity_for_key(self, key: str) -> int:
        if key == "doors":
            return self.doors
        if key == "windows":
            return self.windows
        raise TakeoffError(f"nieznany klucz ilosci: {key!r}")


# --- wczytywanie -----------------------------------------------------------


def room_from_dict(raw: dict[str, Any], index: int) -> Room:
    outline = _as_points(_first_key(raw, OUTLINE_KEYS, "obrysu pomieszczenia"))
    height = float(_first_key(raw, HEIGHT_KEYS, "wysokosci scian"))
    openings_raw: Any = ()
    for key in OPENING_KEYS:
        if key in raw:
            openings_raw = raw[key]
            break
    openings = tuple(_as_openings(openings_raw))
    return Room(
        id=str(raw.get("id") or f"pom{index:02d}"),
        name=str(raw.get("name") or raw.get("nazwa") or raw.get("id") or f"Pomieszczenie {index + 1}"),
        type=str(raw.get("type") or raw.get("typ") or DEFAULT_ROOM_TYPE),
        outline_m=tuple(outline),
        wall_height_m=height,
        openings=openings,
        takeoff=compute_takeoff(outline, height, openings),
    )


def apartment_from_scene(scene: dict[str, Any]) -> Apartment:
    """Mieszkanie ze sceny. Scena z jednym pokojem tez tu przechodzi -
    wtedy mieszkanie ma jedno pomieszczenie typu domyslnego."""
    for key in ROOM_KEYS:
        if key in scene and isinstance(scene[key], list):
            return Apartment(
                rooms=tuple(
                    room_from_dict(raw, i) for i, raw in enumerate(scene[key])
                )
            )
    # scena jednopokojowa
    return Apartment(rooms=(room_from_dict(scene.get("room", scene), 0),))


# --- wycena ----------------------------------------------------------------


@dataclass(frozen=True)
class ApartmentQuote:
    """Wycena mieszkania: pozycje per pomieszczenie plus wspolne."""

    package_id: str
    package_name: str
    currency: str
    per_room: dict[str, Quote] = field(default_factory=dict)
    shared: Quote | None = None
    warnings: tuple[str, ...] = ()

    def _all(self) -> list[Quote]:
        quotes = list(self.per_room.values())
        if self.shared is not None:
            quotes.append(self.shared)
        return quotes

    @property
    def net(self) -> float:
        return _round_money(sum(q.net for q in self._all()))

    @property
    def vat(self) -> float:
        return _round_money(sum(q.vat for q in self._all()))

    @property
    def gross(self) -> float:
        return _round_money(sum(q.gross for q in self._all()))

    @property
    def sendable(self) -> bool:
        return not self.warnings

    def as_text(self) -> str:
        out: list[str] = [f"{self.package_name} ({self.package_id})", "=" * 76]
        for room_id, quote in self.per_room.items():
            out.append(f"  {room_id}")
            for line in quote.lines:
                label = f"    {line.brand} {line.name}"[:52].ljust(52)
                out.append(f"{label} {line.quantity_billed:>8.2f} {line.unit:<4} {line.net:>10,.2f}")
        if self.shared is not None and self.shared.lines:
            out.append("  wspolne")
            for line in self.shared.lines:
                label = f"    {line.brand} {line.name}"[:52].ljust(52)
                out.append(f"{label} {line.quantity_billed:>8.2f} {line.unit:<4} {line.net:>10,.2f}")
        out.append("-" * 76)
        out.append(f"{'netto'.ljust(52)} {'':>13} {self.net:>10,.2f}")
        out.append(f"{'VAT'.ljust(52)} {'':>13} {self.vat:>10,.2f}")
        out.append(f"{'brutto'.ljust(52)} {'':>13} {self.gross:>10,.2f} {self.currency}")
        if self.warnings:
            out.append("")
            out.append("KALKULACJA ROBOCZA - nie do wyslania:")
            for warning in self.warnings:
                out.append(f"  - {warning}")
        return "\n".join(out)


def quote_room(catalog: Catalog, package: Package, room: Room) -> Quote:
    """Same powierzchnie pomieszczenia, z materialami wlasciwymi dla jego typu."""
    lines: list[QuoteLine] = []
    warnings: list[str] = []

    for surface, item_id in sorted(package.surfaces_for(room.type).items()):
        if not item_id:  # jawne "w tym pomieszczeniu tego nie ma"
            continue
        item = catalog.items[item_id]
        quantity = room.takeoff.quantity_for_surface(surface)
        if quantity <= 0:
            continue
        lines.append(
            QuoteLine(
                item_id=item.id,
                name=item.name,
                brand=item.brand,
                unit=item.unit,
                quantity_raw=quantity,
                waste_factor=item.waste_factor,
                quantity_billed=quantity * (1.0 + item.waste_factor),
                unit_price_net=item.price.net,
                vat_rate=item.price.vat_rate,
            )
        )
        for blocker in item.blockers():
            warnings.append(f"{item.brand} {item.name}: {blocker}")

    return Quote(
        package_id=f"{package.id}/{room.id}",
        package_name=f"{package.name} — {room.name}",
        currency=catalog.currency,
        lines=tuple(lines),
        warnings=tuple(dict.fromkeys(warnings)),
    )


def quote_shared(catalog: Catalog, package: Package, apartment: Apartment) -> Quote:
    """Obiekty liczone na cale mieszkanie: drzwi z otworow, meble, oswietlenie."""
    lines: list[QuoteLine] = []
    warnings: list[str] = []

    def dodaj(item_id: str, count: int) -> None:
        if count <= 0:
            return
        item = catalog.items[item_id]
        lines.append(
            QuoteLine(
                item_id=item.id,
                name=item.name,
                brand=item.brand,
                unit=item.unit,
                quantity_raw=float(count),
                waste_factor=0.0,
                quantity_billed=float(count),
                unit_price_net=item.price.net,
                vat_rate=item.price.vat_rate,
            )
        )
        for blocker in item.blockers():
            warnings.append(f"{item.brand} {item.name}: {blocker}")

    for item_id, quantity_key in sorted(package.from_takeoff.items()):
        dodaj(item_id, apartment.quantity_for_key(quantity_key))
    for item_id, count in sorted(package.objects.items()):
        dodaj(item_id, count)

    return Quote(
        package_id=f"{package.id}/wspolne",
        package_name=f"{package.name} — wspolne",
        currency=catalog.currency,
        lines=tuple(lines),
        warnings=tuple(dict.fromkeys(warnings)),
    )


def quote_apartment(
    catalog: Catalog, package: Package, apartment: Apartment
) -> ApartmentQuote:
    per_room = {room.id: quote_room(catalog, package, room) for room in apartment.rooms}
    shared = quote_shared(catalog, package, apartment)

    warnings: list[str] = []
    for quote in list(per_room.values()) + [shared]:
        warnings += [w for w in quote.warnings if w not in warnings]

    return ApartmentQuote(
        package_id=package.id,
        package_name=package.name,
        currency=catalog.currency,
        per_room=per_room,
        shared=shared,
        warnings=tuple(warnings),
    )


def quote_all_packages_for_apartment(
    catalog: Catalog, apartment: Apartment
) -> list[ApartmentQuote]:
    return [
        quote_apartment(catalog, package, apartment)
        for package in sorted(catalog.packages.values(), key=lambda p: p.id)
    ]

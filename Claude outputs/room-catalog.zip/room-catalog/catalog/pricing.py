"""Wycena pakietu wykonczenia: przedmiar x katalog = kwota.

Wycena zawsze niesie ze soba liste zastrzezen. Dopoki lista nie jest pusta,
dokument jest robocza kalkulacja, a nie oferta - i `Quote.sendable` mowi to
wprost, zeby nie dalo sie tego przeoczyc w interfejsie.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .model import Catalog, Item, Package
from .takeoff import Takeoff


def _round_money(value: float) -> float:
    """Zaokraglenie do groszy. Liczymy w floatach, ale kwota do pokazania
    zawsze przechodzi przez to miejsce, wiec sumy sie zgadzaja."""
    return round(value + 1e-9, 2)


@dataclass(frozen=True)
class QuoteLine:
    item_id: str
    name: str
    brand: str
    unit: str
    quantity_raw: float       # z przedmiaru, bez ubytku
    waste_factor: float
    quantity_billed: float    # to, za co klient placi
    unit_price_net: float
    vat_rate: float

    @property
    def net(self) -> float:
        return _round_money(self.quantity_billed * self.unit_price_net)

    @property
    def vat(self) -> float:
        return _round_money(self.net * self.vat_rate)

    @property
    def gross(self) -> float:
        return _round_money(self.net + self.vat)


@dataclass(frozen=True)
class Quote:
    package_id: str
    package_name: str
    currency: str
    lines: tuple[QuoteLine, ...]
    warnings: tuple[str, ...] = field(default=())

    @property
    def net(self) -> float:
        return _round_money(sum(line.net for line in self.lines))

    @property
    def vat(self) -> float:
        return _round_money(sum(line.vat for line in self.lines))

    @property
    def gross(self) -> float:
        return _round_money(sum(line.gross for line in self.lines))

    @property
    def sendable(self) -> bool:
        """Czy wycene wolno pokazac kupujacemu."""
        return not self.warnings

    def as_text(self) -> str:
        width = 46
        out = [f"{self.package_name} ({self.package_id})", "=" * (width + 30)]
        for line in self.lines:
            label = f"{line.brand} {line.name}"[:width].ljust(width)
            qty = f"{line.quantity_billed:>9.2f} {line.unit:<4}"
            out.append(f"{label} {qty} {line.net:>12,.2f}")
        out.append("-" * (width + 30))
        out.append(f"{'netto'.ljust(width)} {'':>14} {self.net:>12,.2f}")
        out.append(f"{'VAT'.ljust(width)} {'':>14} {self.vat:>12,.2f}")
        out.append(f"{'brutto'.ljust(width)} {'':>14} {self.gross:>12,.2f} {self.currency}")
        if self.warnings:
            out.append("")
            out.append("KALKULACJA ROBOCZA - nie do wyslania:")
            for warning in self.warnings:
                out.append(f"  - {warning}")
        return "\n".join(out)


def _line_for_material(item: Item, quantity_raw: float) -> QuoteLine:
    billed = quantity_raw * (1.0 + item.waste_factor)
    return QuoteLine(
        item_id=item.id,
        name=item.name,
        brand=item.brand,
        unit=item.unit,
        quantity_raw=quantity_raw,
        waste_factor=item.waste_factor,
        quantity_billed=billed,
        unit_price_net=item.price.net,
        vat_rate=item.price.vat_rate,
    )


def _line_for_object(item: Item, count: int) -> QuoteLine:
    return QuoteLine(
        item_id=item.id,
        name=item.name,
        brand=item.brand,
        unit=item.unit,
        quantity_raw=float(count),
        waste_factor=0.0,
        quantity_billed=float(count),
        unit_price_net=item.price.net,
        vat_rate=item.price.vat_rate,
    )


def quote_package(
    catalog: Catalog,
    package: Package,
    takeoff: Takeoff,
) -> Quote:
    """Policz wycene jednego pakietu na jednym pomieszczeniu."""
    lines: list[QuoteLine] = []
    warnings: list[str] = []

    def note(item: Item) -> None:
        for blocker in item.blockers():
            warnings.append(f"{item.brand} {item.name}: {blocker}")

    # materialy powierzchniowe
    for surface, item_id in sorted(package.surfaces.items()):
        item = catalog.items[item_id]
        quantity = takeoff.quantity_for_surface(surface)
        lines.append(_line_for_material(item, quantity))
        note(item)

    # obiekty w ilosci wynikajacej z przedmiaru (drzwi, okna)
    for item_id, quantity_key in sorted(package.from_takeoff.items()):
        item = catalog.items[item_id]
        count = takeoff.quantity_for_key(quantity_key)
        if count == 0:
            continue
        lines.append(_line_for_object(item, count))
        note(item)

    # obiekty w ilosci stalej (meble, oswietlenie, akcenty)
    for item_id, count in sorted(package.objects.items()):
        if count == 0:
            continue
        item = catalog.items[item_id]
        lines.append(_line_for_object(item, count))
        note(item)

    return Quote(
        package_id=package.id,
        package_name=package.name,
        currency=catalog.currency,
        lines=tuple(lines),
        warnings=tuple(dict.fromkeys(warnings)),  # bez powtorzen, kolejnosc zachowana
    )


def quote_all_packages(catalog: Catalog, takeoff: Takeoff) -> list[Quote]:
    return [
        quote_package(catalog, package, takeoff)
        for package in sorted(catalog.packages.values(), key=lambda p: p.id)
    ]

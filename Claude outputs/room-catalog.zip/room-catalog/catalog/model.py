"""Model danych katalogu produktow.

Katalog opisuje rzeczy, ktore realnie da sie kupic. Kazda pozycja niesie
ze soba trzy informacje, bez ktorych nie wolno jej pokazac klientowi:
skad pochodzi (source_url), na jakiej podstawie wolno jej uzyc (license)
i czy cena jest prawdziwa (price_status).

Modul nie ma zadnych zaleznosci poza biblioteka standardowa, wiec dziala
zarowno pod pythonem z Blendera, jak i pod czystym python3.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


SCHEMA_VERSION = 1

# --- slowniki kontrolowane -------------------------------------------------

# Na jakiej podstawie wolno uzyc pozycji.
#   example_only    - geometria syntetyczna, tylko do testow; nigdy do klienta
#   cc0             - domena publiczna / CC0, wolno wszystko
#   designer_zone   - pobrane ze strefy projektanta producenta, BEZ pisemnej
#                     zgody na uzycie w aplikacji komercyjnej
#   written_consent - producent potwierdzil na pismie
#   purchased       - kupiona licencja royalty-free
LICENSES = ("example_only", "cc0", "designer_zone", "written_consent", "purchased")

# Ktore licencje wolno wypuscic do sceny ogladanej przez kupujacego mieszkanie.
CLIENT_SAFE_LICENSES = frozenset({"cc0", "written_consent", "purchased"})

#   placeholder - cena zmyslona na potrzeby testu, NIE do pokazania
#   listed      - odczytana recznie z cennika lub sklepu, z data
#   feed        - ciagniete automatycznie ze zrodla (API/feed)
#   quoted      - wynegocjowana z partnerem
PRICE_STATUSES = ("placeholder", "listed", "feed", "quoted")

CLIENT_SAFE_PRICE_STATUSES = frozenset({"listed", "feed", "quoted"})

# Powierzchnie, ktore material moze pokrywac.
SURFACES = ("floor", "wall", "ceiling", "skirting")

# Role w zabudowie parametrycznej (szafy, kuchnie) wraz z jednostka rozliczenia.
# Pozycja typu "component" nie jest ani powierzchnia pomieszczenia, ani bryla
# wstawiana do sceny - to material albo okucie, z ktorego zabudowa powstaje.
CASEWORK_ROLE_UNITS: dict[str, str] = {
    "board_carcass": "m2",
    "board_front": "m2",
    "board_back": "m2",
    "edge_banding": "mb",
    "hinge": "szt",
    "drawer_slide": "szt",
    "handle": "szt",
    "worktop": "mb",
    "plinth": "mb",
}

# Rodzaje obiektow wstawianych do sceny.
SLOTS = ("door", "window", "furniture", "lighting", "sanitary", "decor", "kitchen")

# Jak obiekt jest osadzany w scenie.
ANCHORS = ("floor", "wall", "ceiling", "opening")

UNITS = ("m2", "mb", "szt")

ID_RE = re.compile(r"^[a-z0-9]+(?:[-.][a-z0-9]+)*$")
COLOR_RE = re.compile(r"^#[0-9a-fA-F]{6}$")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


class CatalogError(ValueError):
    """Katalog nie spelnia kontraktu."""


# --- pozycje ---------------------------------------------------------------


@dataclass(frozen=True)
class Provenance:
    """Skad pozycja pochodzi i na jakiej podstawie wolno jej uzyc."""

    source_url: str
    license: str
    license_note: str = ""

    def validate(self, where: str) -> list[str]:
        errs: list[str] = []
        if not self.source_url:
            errs.append(f"{where}: brak source_url")
        if self.license not in LICENSES:
            errs.append(
                f"{where}: license={self.license!r} spoza slownika {LICENSES}"
            )
        return errs

    @property
    def client_safe(self) -> bool:
        return self.license in CLIENT_SAFE_LICENSES


@dataclass(frozen=True)
class Price:
    """Cena jednostkowa netto wraz z informacja, na ile jest prawdziwa."""

    net: float
    vat_rate: float
    status: str
    date: str
    currency: str = "PLN"

    def validate(self, where: str) -> list[str]:
        errs: list[str] = []
        if self.net < 0:
            errs.append(f"{where}: cena netto ujemna ({self.net})")
        if not 0.0 <= self.vat_rate <= 1.0:
            errs.append(
                f"{where}: vat_rate={self.vat_rate} poza zakresem 0..1 "
                "(uzywaj ulamka, np. 0.23 albo 0.08)"
            )
        if self.status not in PRICE_STATUSES:
            errs.append(
                f"{where}: price.status={self.status!r} spoza slownika {PRICE_STATUSES}"
            )
        if not DATE_RE.match(self.date):
            errs.append(f"{where}: price.date={self.date!r} nie jest data RRRR-MM-DD")
        return errs

    @property
    def client_safe(self) -> bool:
        return self.status in CLIENT_SAFE_PRICE_STATUSES

    @property
    def gross(self) -> float:
        return self.net * (1.0 + self.vat_rate)


@dataclass(frozen=True)
class Item:
    """Pojedyncza pozycja katalogu.

    kind == "material": rozlicza sie przez powierzchnie albo dlugosc,
    ma przypisana powierzchnie (surface) i wspolczynnik ubytku.

    kind == "object": rozlicza sie na sztuki, ma wymiary i sposob osadzenia.
    """

    id: str
    kind: str  # "material" | "object"
    name: str
    brand: str
    unit: str
    price: Price
    provenance: Provenance

    product_code: str = ""
    # Barwa zastepcza uzywana, dopoki nie ma tekstury - i jako podklad pod nia.
    # Bez tego wariant bez gotowych map wyglada na bialy, a nie na wybor klienta.
    color: str = ""
    # component (element zabudowy)
    role: str = ""
    # material
    surface: str = ""
    waste_factor: float = 0.0
    module_mm: tuple[int, ...] = ()
    texture: str = ""
    # object
    slot: str = ""
    anchor: str = ""
    dimensions_mm: dict[str, float] = field(default_factory=dict)
    model: str = ""

    def validate(self) -> list[str]:
        where = f"item[{self.id}]"
        errs: list[str] = []

        if not ID_RE.match(self.id):
            errs.append(
                f"{where}: id musi byc male litery/cyfry rozdzielone kropka lub myslnikiem"
            )
        if not self.name:
            errs.append(f"{where}: brak name")
        if not self.brand:
            errs.append(f"{where}: brak brand")
        if self.unit not in UNITS:
            errs.append(f"{where}: unit={self.unit!r} spoza slownika {UNITS}")

        if self.color and not COLOR_RE.match(self.color):
            errs.append(f"{where}: color={self.color!r} nie jest zapisem #rrggbb")

        errs += self.price.validate(where)
        errs += self.provenance.validate(where)

        if self.kind == "material":
            if self.surface not in SURFACES:
                errs.append(
                    f"{where}: surface={self.surface!r} spoza slownika {SURFACES}"
                )
            if self.unit not in ("m2", "mb"):
                errs.append(f"{where}: material rozlicza sie w m2 albo mb, nie {self.unit!r}")
            if not 0.0 <= self.waste_factor < 1.0:
                errs.append(
                    f"{where}: waste_factor={self.waste_factor} poza zakresem 0..1"
                )
            if self.slot or self.anchor:
                errs.append(f"{where}: material nie moze miec slot/anchor")
            if self.role:
                errs.append(f"{where}: material nie moze miec role (to pole jest dla component)")
        elif self.kind == "component":
            if self.role not in CASEWORK_ROLE_UNITS:
                errs.append(
                    f"{where}: role={self.role!r} spoza slownika "
                    f"{tuple(CASEWORK_ROLE_UNITS)}"
                )
            elif self.unit != CASEWORK_ROLE_UNITS[self.role]:
                errs.append(
                    f"{where}: rola {self.role} rozlicza sie w "
                    f"{CASEWORK_ROLE_UNITS[self.role]}, a pozycja jest w {self.unit!r}"
                )
            if not 0.0 <= self.waste_factor < 1.0:
                errs.append(f"{where}: waste_factor={self.waste_factor} poza zakresem 0..1")
            if self.surface or self.slot or self.anchor:
                errs.append(f"{where}: component nie moze miec surface/slot/anchor")
        elif self.kind == "object":
            if self.slot not in SLOTS:
                errs.append(f"{where}: slot={self.slot!r} spoza slownika {SLOTS}")
            if self.anchor not in ANCHORS:
                errs.append(f"{where}: anchor={self.anchor!r} spoza slownika {ANCHORS}")
            if self.unit != "szt":
                errs.append(f"{where}: obiekt rozlicza sie na sztuki, nie {self.unit!r}")
            for axis in ("w", "d", "h"):
                if axis not in self.dimensions_mm:
                    errs.append(f"{where}: brak wymiaru {axis} w dimensions_mm")
                elif self.dimensions_mm[axis] <= 0:
                    errs.append(f"{where}: wymiar {axis} musi byc dodatni")
            if self.surface or self.role:
                errs.append(f"{where}: obiekt nie moze miec surface/role")
        else:
            errs.append(
                f"{where}: kind={self.kind!r}, oczekiwano "
                "'material', 'component' albo 'object'"
            )

        return errs

    @property
    def client_safe(self) -> bool:
        """Czy pozycje wolno pokazac kupujacemu mieszkanie."""
        return self.provenance.client_safe and self.price.client_safe

    def blockers(self) -> list[str]:
        """Czego brakuje, zeby pozycja byla gotowa do pokazania klientowi."""
        out: list[str] = []
        if not self.provenance.client_safe:
            out.append(f"licencja '{self.provenance.license}' nie dopuszcza uzycia komercyjnego")
        if not self.price.client_safe:
            out.append(f"cena ma status '{self.price.status}'")
        if self.kind == "object" and not self.model:
            out.append("brak pliku modelu")
        return out


@dataclass(frozen=True)
class Package:
    """Pakiet wykonczenia sprzedawany przez dewelopera.

    surfaces: powierzchnia -> id materialu
    objects:  id obiektu -> ilosc sztuk (0 = licz z przedmiaru)
    """

    id: str
    name: str
    surfaces: dict[str, str] = field(default_factory=dict)
    objects: dict[str, int] = field(default_factory=dict)
    # Zestaw zabudowy uzyty w tym pakiecie. Pusty = zestaw domyslny.
    # Dzieki temu Standard i Premium moga miec inne fronty przy tym samym
    # ukladzie szafek - a tak wlasnie sprzedaje deweloper.
    casework_kit: str = ""
    # Nadpisania materialow wedlug TYPU pomieszczenia: {"lazienka": {"wall": ...}}.
    # Material nalezy do funkcji pomieszczenia, nie do pakietu: lazienka ma
    # plytke do sufitu, salon farbe, a pakiet jest jeden na cale mieszkanie.
    # Wartosc pusta ("") znaczy "w tym pomieszczeniu tej pozycji nie ma".
    rooms: dict[str, dict[str, str]] = field(default_factory=dict)

    def surfaces_for(self, room_type: str) -> dict[str, str]:
        """Materialy dla pomieszczenia danego typu: domyslne plus nadpisania."""
        rozwiazane = dict(self.surfaces)
        rozwiazane.update(self.rooms.get(room_type, {}))
        return rozwiazane
    # ktore obiekty maja isc na ilosc wynikajaca z przedmiaru, np. drzwi
    from_takeoff: dict[str, str] = field(default_factory=dict)

    def validate(self, items: dict[str, Item]) -> list[str]:
        where = f"package[{self.id}]"
        errs: list[str] = []
        if not ID_RE.match(self.id):
            errs.append(f"{where}: id w zlym formacie")
        if not self.name:
            errs.append(f"{where}: brak name")

        def sprawdz_powierzchnie(gdzie: str, mapa: dict[str, str]) -> None:
            for surface, item_id in mapa.items():
                if surface not in SURFACES:
                    errs.append(f"{gdzie}: nieznana powierzchnia {surface!r}")
                    continue
                if not item_id:
                    continue  # jawny brak pozycji w tym pomieszczeniu
                item = items.get(item_id)
                if item is None:
                    errs.append(f"{gdzie}: powierzchnia {surface} wskazuje na nieznane id {item_id!r}")
                elif item.kind != "material":
                    errs.append(f"{gdzie}: powierzchnia {surface} wskazuje na {item.kind}, nie material")
                elif item.surface != surface:
                    errs.append(
                        f"{gdzie}: material {item_id} jest na {item.surface}, przypisany do {surface}"
                    )

        sprawdz_powierzchnie(where, self.surfaces)
        for room_type, mapa in self.rooms.items():
            if not room_type:
                errs.append(f"{where}: pusty typ pomieszczenia w rooms")
            sprawdz_powierzchnie(f"{where}.rooms[{room_type}]", mapa)

        for item_id, count in self.objects.items():
            item = items.get(item_id)
            if item is None:
                errs.append(f"{where}: nieznane id obiektu {item_id!r}")
            elif item.kind != "object":
                errs.append(f"{where}: {item_id} nie jest obiektem")
            if count < 0:
                errs.append(f"{where}: ujemna ilosc dla {item_id}")

        for item_id, quantity_key in self.from_takeoff.items():
            item = items.get(item_id)
            if item is None:
                errs.append(f"{where}: nieznane id obiektu {item_id!r} w from_takeoff")
            elif item.kind != "object":
                errs.append(f"{where}: {item_id} w from_takeoff nie jest obiektem")
            if quantity_key not in ("doors", "windows"):
                errs.append(
                    f"{where}: from_takeoff[{item_id}]={quantity_key!r}, "
                    "obslugiwane sa 'doors' i 'windows'"
                )
        return errs


@dataclass(frozen=True)
class Catalog:
    schema_version: int
    currency: str
    items: dict[str, Item]
    packages: dict[str, Package]

    def validate(self) -> list[str]:
        errs: list[str] = []
        if self.schema_version != SCHEMA_VERSION:
            errs.append(
                f"schema_version={self.schema_version}, ten kod obsluguje {SCHEMA_VERSION}"
            )
        if not self.currency:
            errs.append("brak currency")
        for item in self.items.values():
            errs += item.validate()
            if item.price.currency != self.currency:
                errs.append(
                    f"item[{item.id}]: waluta {item.price.currency} != katalogowej {self.currency}"
                )
        for package in self.packages.values():
            errs += package.validate(self.items)
        return errs

    def require_valid(self) -> None:
        errs = self.validate()
        if errs:
            raise CatalogError(
                "katalog nie spelnia kontraktu:\n  " + "\n  ".join(errs)
            )


# --- wczytywanie -----------------------------------------------------------


def _price_from_dict(raw: dict[str, Any], currency: str) -> Price:
    return Price(
        net=float(raw.get("net", 0.0)),
        vat_rate=float(raw.get("vat_rate", 0.23)),
        status=str(raw.get("status", "placeholder")),
        date=str(raw.get("date", "")),
        currency=str(raw.get("currency", currency)),
    )


def _provenance_from_dict(raw: dict[str, Any]) -> Provenance:
    return Provenance(
        source_url=str(raw.get("source_url", "")),
        license=str(raw.get("license", "")),
        license_note=str(raw.get("license_note", "")),
    )


def item_from_dict(raw: dict[str, Any], currency: str) -> Item:
    return Item(
        id=str(raw.get("id", "")),
        kind=str(raw.get("kind", "")),
        name=str(raw.get("name", "")),
        brand=str(raw.get("brand", "")),
        unit=str(raw.get("unit", "")),
        price=_price_from_dict(raw.get("price", {}), currency),
        provenance=_provenance_from_dict(raw.get("provenance", {})),
        product_code=str(raw.get("product_code", "")),
        color=str(raw.get("color", "")),
        role=str(raw.get("role", "")),
        surface=str(raw.get("surface", "")),
        waste_factor=float(raw.get("waste_factor", 0.0)),
        module_mm=tuple(int(v) for v in raw.get("module_mm", ())),
        texture=str(raw.get("texture", "")),
        slot=str(raw.get("slot", "")),
        anchor=str(raw.get("anchor", "")),
        dimensions_mm={k: float(v) for k, v in raw.get("dimensions_mm", {}).items()},
        model=str(raw.get("model", "")),
    )


def package_from_dict(raw: dict[str, Any]) -> Package:
    return Package(
        id=str(raw.get("id", "")),
        name=str(raw.get("name", "")),
        surfaces={str(k): str(v) for k, v in raw.get("surfaces", {}).items()},
        objects={str(k): int(v) for k, v in raw.get("objects", {}).items()},
        casework_kit=str(raw.get("casework_kit", "")),
        rooms={
            str(typ): {str(k): str(v) for k, v in mapa.items()}
            for typ, mapa in raw.get("rooms", {}).items()
        },
        from_takeoff={str(k): str(v) for k, v in raw.get("from_takeoff", {}).items()},
    )


def catalog_from_dict(raw: dict[str, Any]) -> Catalog:
    currency = str(raw.get("currency", "PLN"))
    items: dict[str, Item] = {}
    for entry in raw.get("items", []):
        item = item_from_dict(entry, currency)
        if item.id in items:
            raise CatalogError(f"zduplikowane id pozycji: {item.id}")
        items[item.id] = item

    packages: dict[str, Package] = {}
    for entry in raw.get("packages", []):
        package = package_from_dict(entry)
        if package.id in packages:
            raise CatalogError(f"zduplikowane id pakietu: {package.id}")
        packages[package.id] = package

    return Catalog(
        schema_version=int(raw.get("schema_version", 0)),
        currency=currency,
        items=items,
        packages=packages,
    )


def load_catalog(path: str | Path) -> Catalog:
    with open(path, "r", encoding="utf-8") as handle:
        return catalog_from_dict(json.load(handle))

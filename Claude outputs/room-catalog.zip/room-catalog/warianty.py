#!/usr/bin/env python3
"""Zbuduj variants.json - kontrakt wariantow miedzy generatorem a przegladarka.

    python3 warianty.py data/scene.example.json data/catalog.example.json \\
        --zabudowa dolne:base:3000 --zabudowa gorne:wall:2400 \\
        --wyjscie data/variants.json --demo web/warianty-demo.html

Bez --zabudowa warianty obejmuja samo wykonczenie. Zestaw materialowy zabudowy
bierze sie z pola casework_kit przy pakiecie; --zestaw ustawia domyslny dla
pakietow, ktore go nie maja.

--demo sklada samowystarczalny plik HTML z wklejonymi danymi w srodku:
otwiera sie dwuklikiem, dziala bez serwera i bez internetu poza jednym CDN-em.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from catalog import load_catalog  # noqa: E402
from catalog.apartment import apartment_from_scene  # noqa: E402
from catalog.casework import CaseworkError, load_kits, plan_run  # noqa: E402
from catalog.variants import build_variants, client_safe_variants  # noqa: E402

SZABLON = Path(__file__).resolve().parent / "web" / "warianty.template.html"


def _args() -> list[str]:
    argv = sys.argv
    if "--" in argv:
        return argv[argv.index("--") + 1 :]
    return argv[1:]


def _pobierz(args: list[str], flaga: str) -> tuple[list[str], list[str]]:
    """Wyjmij wszystkie wystapienia flagi z wartoscia."""
    wartosci: list[str] = []
    reszta: list[str] = []
    i = 0
    while i < len(args):
        if args[i] == flaga:
            if i + 1 >= len(args):
                raise CaseworkError(f"{flaga} wymaga wartosci")
            wartosci.append(args[i + 1])
            i += 2
        else:
            reszta.append(args[i])
            i += 1
    return reszta, wartosci


def _parse_run(spec: str):
    """nazwa:rodzaj:dlugosc_mm[:id_pomieszczenia]"""
    parts = spec.split(":")
    if len(parts) not in (3, 4):
        raise CaseworkError(
            f"ciag {spec!r}: oczekiwano nazwa:rodzaj:dlugosc_mm[:pomieszczenie]"
        )
    name, kind, length = parts[:3]
    room = parts[3] if len(parts) == 4 else ""
    if not length.isdigit():
        raise CaseworkError(f"dlugosc {length!r} w ciagu {name!r} nie jest liczba mm")
    return plan_run(name, kind, int(length)), room


def main() -> int:
    args = _args()
    args, ciagi = _pobierz(args, "--zabudowa")
    args, zestawy = _pobierz(args, "--zestaw")
    args, wyjscia = _pobierz(args, "--wyjscie")
    args, dema = _pobierz(args, "--demo")

    if len(args) != 2:
        print(__doc__)
        return 2

    scene_path, catalog_path = args

    with open(scene_path, "r", encoding="utf-8") as handle:
        scene = json.load(handle)
    mieszkanie = apartment_from_scene(scene)
    catalog = load_catalog(catalog_path)
    catalog.require_valid()
    kits = load_kits(catalog_path)

    doc = build_variants(
        catalog,
        mieszkanie,
        kits=kits,
        kit_id=zestawy[0] if zestawy else "",
        casework_runs=[_parse_run(spec) for spec in ciagi],
    )

    mieszk = doc["apartment"]
    print(
        f"Mieszkanie: {len(mieszk['rooms'])} pomieszczen, "
        f"{mieszk['floor_area_m2']:.2f} m2 podlog, "
        f"{mieszk['doors']} drzwi, {mieszk['windows']} okien"
    )
    for pokoj in mieszk["rooms"]:
        print(f"  {pokoj['name']:<14} {pokoj['type']:<12} {pokoj['floor_area_m2']:6.2f} m2")

    gotowe = client_safe_variants(doc)
    print(f"\nWariantow: {len(doc['variants'])}, gotowych do oferty: {len(gotowe)}")
    for wariant in doc["variants"]:
        stan = "gotowy" if not wariant["draft"] else f"roboczy ({len(wariant['blockers'])} zastrzezen)"
        print(f"  {wariant['id']:<10} {stan}")
        for room_id, pokoj in wariant["rooms"].items():
            materialy = ", ".join(
                f"{slot}={pokoj['materials'][slot]['item_id']}"
                for slot in doc["room_slots"]
                if slot in pokoj["materials"]
            )
            print(f"    {room_id:<12} {materialy}")

    if wyjscia:
        with open(wyjscia[0], "w", encoding="utf-8") as handle:
            json.dump(doc, handle, ensure_ascii=False, indent=2)
        print(f"\nZapisano {wyjscia[0]}")

    if dema:
        if not SZABLON.exists():
            print(f"brak szablonu {SZABLON}")
            return 2
        html = SZABLON.read_text(encoding="utf-8")
        html = html.replace(
            "__VARIANTS_JSON__", json.dumps(doc, ensure_ascii=False)
        )
        Path(dema[0]).write_text(html, encoding="utf-8")
        rozmiar = Path(dema[0]).stat().st_size / 1024
        print(f"Zapisano {dema[0]} ({rozmiar:.0f} kB) - otwiera sie dwuklikiem")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
